<?php
// kategori_hapus.php
require_once "koneksi.php";
if (!isset($_GET['id'])) {
    header("Location: kategori.php");
    exit;
}
$id = (int)$_GET['id'];

// sebelum hapus, set surat yang terkait kategori ini menjadi null (karena FK ON DELETE SET NULL, tapi kita lakukan juga)
$stmt = mysqli_prepare($conn, "UPDATE surat SET kategori_id = NULL WHERE kategori_id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);

// hapus kategori
$del = mysqli_prepare($conn, "DELETE FROM kategori WHERE id = ?");
mysqli_stmt_bind_param($del, "i", $id);
mysqli_stmt_execute($del);

header("Location: kategori.php");
exit;
?>
