<?php
// hapus.php
require_once "koneksi.php";

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}
$id = (int)$_GET['id'];

// ambil nama file
$stmt = mysqli_prepare($conn, "SELECT file FROM surat WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
if ($row = mysqli_fetch_assoc($res)) {
    $file = $row['file'];
    // hapus record
    $del = mysqli_prepare($conn, "DELETE FROM surat WHERE id = ?");
    mysqli_stmt_bind_param($del, "i", $id);
    if (mysqli_stmt_execute($del)) {
        // hapus file fisik kalau ada
        $path = __DIR__ . "/arsip/" . $file;
        if (file_exists($path)) @unlink($path);
    }
}
header("Location: index.php");
exit;
?>
