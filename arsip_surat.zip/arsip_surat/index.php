<?php
require_once "koneksi.php";

// Fitur search
$keyword = isset($_GET['cari']) ? trim($_GET['cari']) : '';

if ($keyword !== '') {
    $stmt = mysqli_prepare($conn, 
        "SELECT s.*, k.nama AS kategori 
         FROM surat s 
         LEFT JOIN kategori k ON s.kategori_id = k.id 
         WHERE s.judul LIKE ? 
         ORDER BY s.id DESC");
    if ($stmt) {
        $param = "%".$keyword."%";
        mysqli_stmt_bind_param($stmt, "s", $param);
    }
} else {
    $stmt = mysqli_prepare($conn, 
        "SELECT s.*, k.nama AS kategori 
         FROM surat s 
         LEFT JOIN kategori k ON s.kategori_id = k.id 
         ORDER BY s.id DESC");
}

if ($stmt) {
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
} else {
    die("Query gagal: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Aplikasi Arsip Surat</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background-color: #f4f6f9;
    }
    .sidebar {
      min-height: 100vh;
      background-color: #343a40;
      color: #fff;
    }
    .sidebar a {
      color: #adb5bd;
      text-decoration: none;
      display: block;
      padding: 12px 20px;
    }
    .sidebar a:hover {
      background-color: #495057;
      color: #fff;
    }
    .active {
      background-color: #495057;
      color: #fff !important;
    }
    .content {
      padding: 20px;
    }
  </style>
</head>
<body>
<div class="container-fluid">
  <div class="row">
    <!-- Sidebar -->
    <div class="col-md-3 col-lg-2 sidebar">
      <h4 class="text-center py-3 border-bottom">📂 Arsip Surat</h4>
      <a href="index.php" class="active">Arsip Surat</a>
      <a href="kategori.php">Kategori Surat</a>
      <a href="about.php">About</a>
    </div>

    <!-- Main Content -->
    <div class="col-md-9 col-lg-10 content">
      <h3 class="mb-4">📑 Daftar Arsip Surat</h3>

      <!-- Search -->
      <form class="d-flex mb-3" method="GET">
        <input type="text" class="form-control me-2" name="cari" 
               value="<?= htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8'); ?>" 
               placeholder="Cari berdasarkan judul...">
        <button type="submit" class="btn btn-primary">Cari</button>
        <a href="index.php" class="btn btn-secondary ms-2">Reset</a>
      </form>

      <!-- Tombol Arsipkan -->
      <a href="tambah.php" class="btn btn-success mb-3">+ Arsipkan Surat</a>

      <!-- Tabel Surat -->
      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
          <thead class="table-dark text-center">
            <tr>
              <th>No</th>
              <th>Judul</th>
              <th>Kategori</th>
              <th>Waktu Unggah</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
          <?php 
          $no = 1;
          if(mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) { ?>
              <tr>
                <td class="text-center"><?= $no++; ?></td>
                <td><?= htmlspecialchars($row['judul'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?= htmlspecialchars($row['kategori'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></td>
                <td><?= htmlspecialchars($row['created_at'], ENT_QUOTES, 'UTF-8'); ?></td>
                <td class="text-center">
                  <a href="lihat.php?id=<?= $row['id']; ?>" class="btn btn-info btn-sm">Lihat >></a>
                  <a href="download.php?id=<?= $row['id']; ?>" class="btn btn-primary btn-sm">Unduh</a>
                  <a href="hapus.php?id=<?= $row['id']; ?>" class="btn btn-danger btn-sm"
                     onclick="return confirm('Apakah Anda yakin ingin menghapus surat ini?');">Hapus</a>
                </td>
              </tr>
            <?php }
          } else {
            echo "<tr><td colspan='5' class='text-center'>Tidak ada data surat.</td></tr>";
          } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</body>
</html>
<?php
if (isset($stmt)) {
    mysqli_stmt_close($stmt);
}
mysqli_close($conn);
?>
