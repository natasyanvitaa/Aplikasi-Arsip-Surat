<?php
// tambah.php
require_once "koneksi.php";

// ambil daftar kategori
$katRes = mysqli_query($conn, "SELECT * FROM kategori ORDER BY nama");

$err = "";
if (isset($_POST['simpan'])) {
    $judul = trim($_POST['judul']);
    $kategori_id = ($_POST['kategori'] === "") ? null : (int)$_POST['kategori'];

    if ($judul === "") {
        $err = "Judul wajib diisi.";
    } elseif (!isset($_FILES['file']) || $_FILES['file']['error'] != UPLOAD_ERR_OK) {
        $err = "File PDF wajib diunggah.";
    } else {
        $file = $_FILES['file'];

        // cek ekstensi dan mime
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if ($ext !== 'pdf' || $mime !== 'application/pdf') {
            $err = "File harus berupa PDF.";
        } else {
            // buat nama unik
            $newName = time() . "_" . preg_replace("/[^a-zA-Z0-9_\-\.]/", "_", basename($file['name']));

            $targetDir = __DIR__ . DIRECTORY_SEPARATOR . "arsip" . DIRECTORY_SEPARATOR;
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0777, true);
            }

            $dest = $targetDir . $newName;

            if (!move_uploaded_file($file['tmp_name'], $dest)) {
                $err = "Gagal menyimpan file ke folder arsip.";
            } else {
                // insert ke DB
                $stmt = mysqli_prepare($conn, "INSERT INTO surat (judul, kategori_id, file, created_at) VALUES (?, ?, ?, NOW())");

                if ($kategori_id === null) {
                    // kalau null, gunakan bind_param dengan "s" dan set null via variable
                    $null = null;
                    mysqli_stmt_bind_param($stmt, "sis", $judul, $null, $newName);
                } else {
                    mysqli_stmt_bind_param($stmt, "sis", $judul, $kategori_id, $newName);
                }

                if (mysqli_stmt_execute($stmt)) {
                    echo "<script>alert('Data berhasil disimpan');window.location='index.php';</script>";
                    exit;
                } else {
                    $err = "Gagal menyimpan ke database: " . mysqli_error($conn);
                    @unlink($dest);
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Arsipkan Surat</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background: #f4f6f9; font-family: "Segoe UI", sans-serif; }
    .container { margin-top: 40px; }
    .card { border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.08); }
    footer { text-align: center; padding: 15px; color: #777; }
  </style>
</head>
<body>
<div class="container">
  <div class="card p-4">
    <h2 class="mb-3">Arsipkan Surat</h2>

    <?php if ($err): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($err) ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Judul Surat</label>
        <input type="text" name="judul" class="form-control" required
               value="<?= isset($_POST['judul']) ? htmlspecialchars($_POST['judul']) : '' ?>">
      </div>

      <div class="mb-3">
        <label class="form-label">Kategori</label>
        <select name="kategori" class="form-select" required>
          <option value="">-- Pilih Kategori --</option>
          <?php while($k = mysqli_fetch_assoc($katRes)): ?>
            <option value="<?= $k['id'] ?>" <?= (isset($_POST['kategori']) && $_POST['kategori']==$k['id']) ? 'selected' : '' ?>>
              <?= htmlspecialchars($k['nama']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="mb-3">
        <label class="form-label">File Surat (PDF)</label>
        <input type="file" name="file" accept="application/pdf" class="form-control" required>
      </div>

      <div>
        <button class="btn btn-primary" type="submit" name="simpan">Simpan</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
      </div>
    </form>
  </div>
</div>
</body>
</html>
