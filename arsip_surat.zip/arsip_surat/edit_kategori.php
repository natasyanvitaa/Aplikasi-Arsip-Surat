<?php
require_once "koneksi.php";

// Cek ID
if (!isset($_GET['id'])) {
    header("Location: kategori.php");
    exit;
}

$id = (int) $_GET['id'];

// Ambil data lama
$stmt = mysqli_prepare($conn, "SELECT * FROM kategori WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$kategori = mysqli_fetch_assoc($result);

if (!$kategori) {
    die("Kategori tidak ditemukan.");
}

// Update data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = trim($_POST['nama']);

    if ($nama !== '') {
        $stmt = mysqli_prepare($conn, "UPDATE kategori SET nama=? WHERE id=?");
        mysqli_stmt_bind_param($stmt, "si", $nama, $id);
        mysqli_stmt_execute($stmt);

        header("Location: kategori.php");
        exit;
    } else {
        $error = "Nama kategori tidak boleh kosong!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Kategori</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
  <h3>✏️ Edit Kategori</h3>
  
  <?php if (!empty($error)) { ?>
    <div class="alert alert-danger"><?= $error; ?></div>
  <?php } ?>

  <form method="POST">
    <div class="mb-3">
      <label for="nama" class="form-label">Nama Kategori</label>
      <input type="text" id="nama" name="nama" class="form-control" 
             value="<?= htmlspecialchars($kategori['nama']); ?>" required>
    </div>
    <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
    <a href="kategori.php" class="btn btn-secondary">Batal</a>
  </form>
</div>
</body>
</html>
