<?php
require_once "koneksi.php";

// cek id
if (!isset($_GET['id'])) {
    die("ID tidak ditemukan.");
}
$id = (int)$_GET['id'];

// ambil nama file dari database
$stmt = mysqli_prepare($conn, "SELECT file FROM surat WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($res);

if (!$data) {
    die("Data surat tidak ditemukan.");
}

$filename = basename($data['file']);
$filepath = __DIR__ . "/arsip/" . $filename;

if (!file_exists($filepath)) {
    die("File tidak tersedia.");
}

// pastikan buffer kosong sebelum header
if (ob_get_length()) ob_end_clean();

// set header download
header('Content-Description: File Transfer');
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($filepath));

flush();
readfile($filepath);
exit;
