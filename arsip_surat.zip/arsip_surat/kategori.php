<?php
require_once "koneksi.php";

// ambil data kategori
$sql = "SELECT * FROM kategori ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Kategori</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2 class="mb-3">Daftar Kategori</h2>

    <a href="kategori_form.php" class="btn btn-success mb-3">+ Tambah Kategori</a>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th width="50">No</th>
                <th>Nama Kategori</th>
                <th width="180">Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php
        if (mysqli_num_rows($result) > 0) {
            $no = 1;
            while ($row = mysqli_fetch_assoc($result)) {
                ?>
                <tr>
                    <td><?= $no++; ?></td>
                    <td><?= htmlspecialchars($row['nama']); ?></td>
                    <td>
                        <a href="kategori_form.php?id=<?= $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="kategori_hapus.php?id=<?= $row['id']; ?>" 
                           onclick="return confirm('Yakin ingin menghapus kategori ini?');"
                           class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
                <?php
            }
        } else {
            echo "<tr><td colspan='3' class='text-center'>Belum ada kategori.</td></tr>";
        }
        ?>
        </tbody>
    </table>

    <a href="index.php" class="btn btn-secondary">← Kembali ke Arsip Surat</a>
</div>
</body>
</html>
