<?php
// kategori_form.php
require_once "koneksi.php";

// ambil ID jika ada
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$nama = "";

// jika ID ada, ambil data kategori untuk edit
if ($id > 0) {
    $stmt = mysqli_prepare($conn, "SELECT * FROM kategori WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($res);
    if ($row) {
        $nama = $row['nama'];
    } else {
        // ID tidak valid
        header("Location: kategori.php");
        exit;
    }
}

// proses simpan
if (isset($_POST['simpan'])) {
    $namaPost = trim($_POST['nama']);
    if ($namaPost === '') {
        $err = "Nama kategori tidak boleh kosong.";
    } else {
        if ($id > 0) {
            // update
            $stmt = mysqli_prepare($conn, "UPDATE kategori SET nama = ? WHERE id = ?");
            mysqli_stmt_bind_param($stmt, "si", $namaPost, $id);
            mysqli_stmt_execute($stmt);
        } else {
            // tambah
            $stmt = mysqli_prepare($conn, "INSERT INTO kategori (nama) VALUES (?)");
            mysqli_stmt_bind_param($stmt, "s", $namaPost);
            mysqli_stmt_execute($stmt);
        }
        header("Location: kategori.php");
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title><?= ($id > 0) ? 'Edit Kategori' : 'Tambah Kategori' ?></title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">
    <h2><?= ($id > 0) ? 'Edit Kategori' : 'Tambah Kategori' ?></h2>

    <?php if (isset($err) && $err): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($err) ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="mb-3">
            <label for="nama" class="form-label">Nama Kategori</label>
            <input type="text" name="nama" id="nama" class="form-control" required
                   value="<?= htmlspecialchars(isset($_POST['nama']) ? $_POST['nama'] : $nama) ?>">
        </div>
        <button type="submit" name="simpan" class="btn btn-primary">Simpan</button>
        <a href="kategori.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>
