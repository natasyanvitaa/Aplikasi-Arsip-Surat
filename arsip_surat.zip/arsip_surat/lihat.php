<?php
// lihat.php
require_once "koneksi.php";
if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit;
}
$id = (int)$_GET['id'];

$stmt = mysqli_prepare($conn, "SELECT s.*, k.nama as kategori FROM surat s LEFT JOIN kategori k ON s.kategori_id=k.id WHERE s.id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($res);
if (!$data) {
    echo "Data tidak ditemukan.";
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <head>
  <title>Aplikasi Arsip Surat</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      background: #f4f6f9;
      font-family: "Segoe UI", sans-serif;
    }
    .container {
      margin-top: 40px;
    }
    .card {
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    }
    .btn-custom {
      border-radius: 8px;
    }
    footer {
      text-align: center;
      padding: 15px;
      color: #777;
    }
  </style>
</head>

    <meta charset="utf-8">
    <title>Detail Surat</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h2>Detail Surat</h2>
    <p><strong>Judul:</strong> <?= htmlspecialchars($data['judul']) ?></p>
    <p><strong>Kategori:</strong> <?= htmlspecialchars($data['kategori'] ?? '-') ?></p>
    <p><strong>Waktu Unggah:</strong> <?= $data['created_at'] ?></p>

    <div style="margin-top:10px;">
        <iframe src="arsip/<?= rawurlencode($data['file']) ?>" width="100%" height="600"></iframe>
    </div>

    <div style="margin-top:10px;">
        <button class="btn" onclick="window.location.href='index.php'">Kembali <<</button>
        <a class="btn btn-primary" href="download.php?id=<?= $data['id'] ?>">Unduh</a>
    </div>
</div>
</body>
</html>
