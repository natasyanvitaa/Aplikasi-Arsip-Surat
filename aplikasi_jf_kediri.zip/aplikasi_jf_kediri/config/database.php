<?php
// config/database.php
// Cukup include db.php jika koneksi sudah didefinisikan di sana
require_once __DIR__ . '/../db.php'; 
?>
