-- Database Integration Script for JF Kediri
-- Membuat struktur database untuk integrasi OPD -> JF -> Pembina -> Koordinator

-- 1. Membuat tabel mapping untuk integrasi
CREATE TABLE IF NOT EXISTS opd_jf_mapping (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_instansi INT NOT NULL,
    id_jf INT NOT NULL,
    id_pembina_jf INT NOT NULL,
    id_koordinator_jf INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_instansi) REFERENCES instansi(id_instansi) ON DELETE CASCADE,
    FOREIGN KEY (id_jf) REFERENCES jabatan_fungsional(id_jf) ON DELETE CASCADE,
    FOREIGN KEY (id_pembina_jf) REFERENCES pembina_jf(id_pembina_jf) ON DELETE CASCADE,
    FOREIGN KEY (id_koordinator_jf) REFERENCES koordinator_jf(id_koordinator_jf) ON DELETE CASCADE,
    UNIQUE KEY unique_mapping (id_instansi, id_jf)
);

-- 2. Membuat tabel untuk menyimpan data mapping yang valid
CREATE TABLE IF NOT EXISTS opd_jf_valid_mapping (
    id INT AUTO_INCREMENT PRIMARY KEY,
    opd_name VARCHAR(255) NOT NULL,
    jf_name VARCHAR(255) NOT NULL,
    pembina_jf_name VARCHAR(255) NOT NULL,
    koordinator_jf_name VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Menambahkan kolom untuk integrasi di tabel existing
ALTER TABLE jf_opd_tracking 
ADD COLUMN IF NOT EXISTS id_pembina_jf INT DEFAULT NULL,
ADD COLUMN IF NOT EXISTS id_koordinator_jf INT DEFAULT NULL,
ADD FOREIGN KEY (id_pembina_jf) REFERENCES pembina_jf(id_pembina_jf),
ADD FOREIGN KEY (id_koordinator_jf) REFERENCES koordinator_jf(id_koordinator_jf);

-- 4. Membuat view untuk integrasi data
CREATE OR REPLACE VIEW v_opd_jf_integrated AS
SELECT 
    t.id_tracking,
    i.nama_instansi as opd_name,
    i.id_instansi,
    jf.nama_jf as jf_name,
    jf.id_jf,
    pj.nama_pembina as pembina_name,
    pj.id_pembina_jf,
    kj.nama_koordinator as koordinator_name,
    kj.id_koordinator_jf,
    t.jumlah_pegawai,
    t.status_tracking,
    t.created_at
FROM jf_opd_tracking t
JOIN instansi i ON t.id_instansi = i.id_instansi
JOIN jabatan_fungsional jf ON t.id_jf = jf.id_jf
LEFT JOIN pembina_jf pj ON t.id_pembina_jf = pj.id_pembina_jf
LEFT JOIN koordinator_jf kj ON t.id_koordinator_jf = kj.id_koordinator_jf;

-- 5. Insert data mapping berdasarkan data yang Anda berikan
-- Contoh mapping untuk beberapa OPD dan JF yang relevan
INSERT INTO opd_jf_valid_mapping (opd_name, jf_name, pembina_jf_name, koordinator_jf_name) VALUES
('Inspektur Inspektorat', 'Auditor', 'Inspektorat', 'Koordinator JF Inspektorat'),
('Kepala Bappeda', 'Perencana', 'Kementerian Perencanaan Pembangunan', 'Koordinator JF Bappeda'),
('Kepala BKPSDM', 'Analis Sumber Daya Manusia Aparatur', 'Badan Kepegawaian Negara', 'Koordinator JF BKPSDM'),
('Kepala BPPKAD', 'Analis Keuangan', 'Kementerian Keuangan', 'Koordinator JF BPKAD'),
('Kepala BPBD', 'Analis Kebencanaan', 'Badan Nasional Penanggulangan Bencana', 'Koordinator JF BPBD'),
('Kepala Dinas PUPR', 'Teknik Jalan dan Jembatan', 'Kementerian Pekerjaan Umum', 'Koordinator JF Dinas PUPR'),
('Kepala Dinas Kesehatan', 'Dokter', 'Kementerian Kesehatan', 'Koordinator JF Dinas Kesehatan'),
('Kepala Dinas Pendidikan', 'Guru', 'Kementerian Pendidikan', 'Koordinator JF Dinas Pendidikan'),
('Kepala Satpol PP', 'Polisi Pamong Praja', 'Kementerian Dalam Negeri', 'Koordinator JF Satpol PP'),
('Direktur RSUD Gambiran', 'Dokter', 'Kementerian Kesehatan', 'Koordinator JF RSUD Gambiran');

-- 6. Membuat stored procedure untuk validasi mapping
DELIMITER //
CREATE PROCEDURE IF NOT EXISTS ValidateOPDJFMapping(
    IN p_opd_id INT,
    IN p_jf_id INT,
    OUT p_is_valid BOOLEAN
)
BEGIN
    DECLARE v_count INT DEFAULT 0;
    
    SELECT COUNT(*) INTO v_count
    FROM opd_jf_valid_mapping vm
    JOIN instansi i ON vm.opd_name = i.nama_instansi
    JOIN jabatan_fungsional jf ON vm.jf_name = jf.nama_jf
    WHERE i.id_instansi = p_opd_id AND jf.id_jf = p_jf_id;
    
    SET p_is_valid = (v_count > 0);
END //
DELIMITER ;

-- 7. Membuat trigger untuk otomatisasi mapping
DELIMITER //
CREATE TRIGGER IF NOT EXISTS after_jf_opd_insert
AFTER INSERT ON jf_opd_tracking
FOR EACH ROW
BEGIN
    -- Update pembina dan koordinator berdasarkan mapping
    UPDATE jf_opd_tracking t
    SET 
        t.id_pembina_jf = (
            SELECT pj.id_pembina_jf 
            FROM opd_jf_valid_mapping vm
            JOIN instansi i ON vm.opd_name = i.nama_instansi
            JOIN jabatan_fungsional jf ON vm.jf_name = jf.nama_jf
            JOIN pembina_jf pj ON vm.pembina_jf_name = pj.nama_pembina
            WHERE i.id_instansi = NEW.id_instansi AND jf.id_jf = NEW.id_jf
            LIMIT 1
        ),
        t.id_koordinator_jf = (
            SELECT kj.id_koordinator_jf 
            FROM opd_jf_valid_mapping vm
            JOIN instansi i ON vm.opd_name = i.nama_instansi
            JOIN jabatan_fungsional jf ON vm.jf_name = jf.nama_jf
            JOIN koordinator_jf kj ON vm.koordinator_jf_name = kj.nama_koordinator
            WHERE i.id_instansi = NEW.id_instansi AND jf.id_jf = NEW.id_jf
            LIMIT 1
        )
    WHERE t.id_tracking = NEW.id_tracking;
END //
DELIMITER ;
