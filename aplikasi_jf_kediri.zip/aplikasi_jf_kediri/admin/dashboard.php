<?php
require_once '../includes/header.php';
require_once '../functions.php';

// Ambil statistik untuk dashboard
$stats = array();

// Total Instansi
$result = $conn->query("SELECT COUNT(*) as total FROM instansi");
$stats['total_instansi'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['total'] : 0;

// Total Jabatan Fungsional
$result = $conn->query("SELECT COUNT(*) as total FROM jabatan_fungsional");
$stats['total_jf'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['total'] : 0;

// Total Jenjang JF
$result = $conn->query("SELECT COUNT(*) as total FROM jenjang_jf");
$stats['total_jenjang'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['total'] : 0;

// Total Rekap JF
$result = $conn->query("SELECT COUNT(*) as total FROM rekap_jf");
$stats['total_rekap'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['total'] : 0;

// Rekap Belum Validasi
$result = $conn->query("SELECT COUNT(*) as total FROM rekap_jf WHERE status_validasi = 'Belum Validasi'");
$stats['rekap_belum_validasi'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['total'] : 0;

// Rekap Sudah Validasi
$result = $conn->query("SELECT COUNT(*) as total FROM rekap_jf WHERE status_validasi = 'Sudah Validasi'");
$stats['rekap_sudah_validasi'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['total'] : 0;

// Total Pegawai (dari tabel pegawai jika ada, atau hitung dari rekap_jf)
$table_check = $conn->query("SHOW TABLES LIKE 'pegawai'");
if ($table_check && $table_check->num_rows > 0) {
    $result = $conn->query("SELECT COUNT(*) as total FROM pegawai");
    $stats['total_pegawai'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['total'] : 0;
} else {
    // Jika tabel pegawai tidak ada, hitung unique pegawai dari rekap_jf
    $result = $conn->query("SELECT COUNT(DISTINCT nip) as total FROM rekap_jf");
    $stats['total_pegawai'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['total'] : 0;
}

// Total Pegawai dengan JF (hitung dari rekap_jf yang memiliki jabatan fungsional)
$result = $conn->query("SELECT COUNT(DISTINCT nip) as total FROM rekap_jf WHERE id_jf IS NOT NULL AND id_jf != ''");
$stats['total_pegawai_jf'] = ($result && $result->num_rows > 0) ? $result->fetch_assoc()['total'] : 0;

// JF-OPD Tracking Statistics (check if table exists first)
$jf_opd_stats = array('total_tracking' => 0, 'belum_dihitung' => 0, 'selesai' => 0, 'total_pembina' => 0, 'total_koordinator' => 0);
$table_check = $conn->query("SHOW TABLES LIKE 'jf_opd_tracking'");
if ($table_check->num_rows > 0) {
    // Total JF-OPD Tracking
    $result = $conn->query("SELECT COUNT(*) as total FROM jf_opd_tracking");
    if ($result) $jf_opd_stats['total_tracking'] = $result->fetch_assoc()['total'];
    
    // Belum Dihitung
    $result = $conn->query("SELECT COUNT(*) as total FROM jf_opd_tracking WHERE status_tracking = 0");
    if ($result) $jf_opd_stats['belum_dihitung'] = $result->fetch_assoc()['total'];
    
    // Selesai (Dasar Hukum)
    $result = $conn->query("SELECT COUNT(*) as total FROM jf_opd_tracking WHERE status_tracking = 6");
    if ($result) $jf_opd_stats['selesai'] = $result->fetch_assoc()['total'];
    
    // Total Pembina JF
    $result = $conn->query("SELECT COUNT(*) as total FROM pembina_jf WHERE status_aktif = 'aktif'");
    if ($result) $jf_opd_stats['total_pembina'] = $result->fetch_assoc()['total'];
    
    // Total Koordinator JF
    $result = $conn->query("SELECT COUNT(*) as total FROM koordinator_jf WHERE status_aktif = 'aktif'");
    if ($result) $jf_opd_stats['total_koordinator'] = $result->fetch_assoc()['total'];
}
?>

<h2 class="page-title">Dashboard</h2>

<div class="dashboard-welcome">
    <div class="alert alert-info">
        <strong>Selamat datang di Sistem Pendataan Jabatan Fungsional Kota Kediri!</strong><br>
        Gunakan menu navigasi di atas untuk mengelola data jabatan fungsional.
    </div>
</div>

<div class="dashboard-stats">
    <div class="stat-box">
        <div class="stat-icon">🏢</div>
        <h3>Total Instansi</h3>
        <span class="stat-number"><?php echo $stats['total_instansi']; ?></span>
        <div class="stat-label">Unit Kerja Terdaftar</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">👔</div>
        <h3>Jabatan Fungsional</h3>
        <span class="stat-number"><?php echo $stats['total_jf']; ?></span>
        <div class="stat-label">Jenis JF Tersedia</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">📊</div>
        <h3>Jenjang JF</h3>
        <span class="stat-number"><?php echo $stats['total_jenjang']; ?></span>
        <div class="stat-label">Level Jenjang</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">👥</div>
        <h3>Total Pegawai</h3>
        <span class="stat-number"><?php echo $stats['total_pegawai']; ?></span>
        <div class="stat-label">Pegawai Terdaftar</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">🎯</div>
        <h3>Pegawai Ber-JF</h3>
        <span class="stat-number"><?php echo $stats['total_pegawai_jf']; ?></span>
        <div class="stat-label">Memiliki Jabatan Fungsional</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">📋</div>
        <h3>Total Rekap</h3>
        <span class="stat-number"><?php echo $stats['total_rekap']; ?></span>
        <div class="stat-label">Data Rekapitulasi</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">⏳</div>
        <h3>Belum Validasi</h3>
        <span class="stat-number"><?php echo $stats['rekap_belum_validasi']; ?></span>
        <div class="stat-label">Menunggu Validasi</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">✅</div>
        <h3>Sudah Validasi</h3>
        <span class="stat-number"><?php echo $stats['rekap_sudah_validasi']; ?></span>
        <div class="stat-label">Telah Divalidasi</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">🔄</div>
        <h3>JF-OPD Tracking</h3>
        <span class="stat-number"><?php echo $jf_opd_stats['total_tracking']; ?></span>
        <div class="stat-label">Total Tracking</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">⚠️</div>
        <h3>Belum Dihitung</h3>
        <span class="stat-number"><?php echo $jf_opd_stats['belum_dihitung']; ?></span>
        <div class="stat-label">Status Tracking</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">🏆</div>
        <h3>Selesai</h3>
        <span class="stat-number"><?php echo $jf_opd_stats['selesai']; ?></span>
        <div class="stat-label">Dasar Hukum Dibuat</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">👨‍💼</div>
        <h3>Pembina JF</h3>
        <span class="stat-number"><?php echo $jf_opd_stats['total_pembina']; ?></span>
        <div class="stat-label">Aktif</div>
    </div>
    
    <div class="stat-box">
        <div class="stat-icon">🤝</div>
        <h3>Koordinator JF</h3>
        <span class="stat-number"><?php echo $jf_opd_stats['total_koordinator']; ?></span>
        <div class="stat-label">Aktif</div>
    </div>
</div>

<div class="dashboard-content">
    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4>Menu Cepat</h4>
                </div>
                <div class="card-body">
                    <div class="quick-menu">
                        <a href="instansi.php" class="btn btn-primary">Kelola OPD</a>
                        <a href="jabatan_fungsional.php" class="btn btn-success">Kelola JF</a>
                        <a href="pegawai.php" class="btn btn-info">Data Pegawai</a>
                        <a href="rekap_jf.php" class="btn btn-warning">Input Rekap</a>
                        <a href="validasi_rekap.php" class="btn btn-secondary">Validasi Data</a>
                        <a href="laporan.php" class="btn btn-danger">Lihat Laporan</a>
                        <hr>
                        <h6 class="text-muted mb-2">Fitur JF-OPD Tracking:</h6>
                        <a href="jf_opd_management.php" class="btn btn-dark btn-sm">JF-OPD Tracking</a>
                        <a href="pembina_jf.php" class="btn btn-outline-primary btn-sm">Pembina JF</a>
                        <a href="koordinator_jf.php" class="btn btn-outline-success btn-sm">Koordinator JF</a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h4>Aktivitas Terbaru</h4>
                </div>
                <div class="card-body">
                    <div class="recent-activity">
                        <?php
                        // Ambil 5 data rekap terbaru
                        $sql = "SELECT r.*, i.nama_instansi, j.nama_jf, jj.nama_jenjang 
                                FROM rekap_jf r
                                JOIN instansi i ON r.id_instansi = i.id_instansi
                                JOIN jabatan_fungsional j ON r.id_jf = j.id_jf
                                JOIN jenjang_jf jj ON r.id_jenjang = jj.id_jenjang
                                ORDER BY r.tanggal_input DESC LIMIT 5";
                        $result = $conn->query($sql);
                        
                        if ($result && $result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $status_class = '';
                                switch($row['status_validasi']) {
                                    case 'Sudah Validasi': $status_class = 'badge-success'; break;
                                    case 'Belum Validasi': $status_class = 'badge-warning'; break;
                                    case 'Ditolak': $status_class = 'badge-danger'; break;
                                }
                                
                                echo "<div class='activity-item'>";
                                echo "<div class='activity-content'>";
                                echo "<strong>" . $row['nama_instansi'] . "</strong><br>";
                                echo "<small>" . $row['nama_jf'] . " - " . $row['nama_jenjang'] . "</small><br>";
                                echo "<span class='badge {$status_class}'>" . $row['status_validasi'] . "</span>";
                                echo "<div class='activity-time'>" . format_tanggal($row['tanggal_input']) . "</div>";
                                echo "</div>";
                                echo "</div>";
                            }
                        } else {
                            echo "<p class='text-center'>Belum ada aktivitas terbaru.</p>";
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="dashboard-info">
    <div class="card">
        <div class="card-header">
            <h4>Petunjuk Penggunaan</h4>
        </div>
        <div class="card-body">
            <div class="user-guide">
                <h5>Langkah-langkah Penggunaan Sistem:</h5>
                <ol>
                    <li><strong>Data Master:</strong> Pastikan data Instansi, Jabatan Fungsional, dan Jenjang JF sudah lengkap</li>
                    <li><strong>Data Pegawai:</strong> Input data pegawai individual sebagai referensi</li>
                    <li><strong>Rekap JF:</strong> Input data rekapitulasi dari setiap instansi</li>
                    <li><strong>Validasi:</strong> Lakukan validasi terhadap data rekap yang telah diinput</li>
                    <li><strong>Laporan:</strong> Generate laporan untuk pelaporan ke instansi terkait</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>

