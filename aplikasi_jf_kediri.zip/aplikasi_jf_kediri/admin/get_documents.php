<?php
require_once '../db.php';
require_once '../functions.php';

if (!isset($_GET['id_tracking'])) {
    echo "<p class='text-center text-muted'>ID tracking tidak ditemukan.</p>";
    exit;
}

$id_tracking = intval($_GET['id_tracking']);

$stmt = $conn->prepare("SELECT * FROM dokumen_pendukung WHERE id_tracking = ? ORDER BY created_at DESC");
$stmt->bind_param("i", $id_tracking);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "<div class='list-group'>";
    while ($row = $result->fetch_assoc()) {
        $file_icon = 'fa-file';
        if (strpos($row['tipe_file'], 'pdf') !== false) {
            $file_icon = 'fa-file-pdf text-danger';
        } elseif (strpos($row['tipe_file'], 'word') !== false || strpos($row['nama_file'], '.doc') !== false) {
            $file_icon = 'fa-file-word text-primary';
        }
        
        echo "<div class='list-group-item'>";
        echo "<div class='d-flex w-100 justify-content-between'>";
        echo "<h6 class='mb-1'><i class='fas {$file_icon}'></i> " . htmlspecialchars($row['nama_asli']) . "</h6>";
        echo "<small>" . format_tanggal($row['created_at']) . "</small>";
        echo "</div>";
        echo "<p class='mb-1'>" . htmlspecialchars($row['keterangan']) . "</p>";
        echo "<small class='text-muted'>Ukuran: " . format_file_size($row['ukuran_file']) . " | Upload oleh: " . htmlspecialchars($row['uploaded_by']) . "</small>";
        echo "<div class='mt-2'>";
        echo "<a href='" . htmlspecialchars($row['path_file']) . "' target='_blank' class='btn btn-sm btn-outline-primary'>";
        echo "<i class='fas fa-download'></i> Download";
        echo "</a>";
        echo "</div>";
        echo "</div>";
    }
    echo "</div>";
} else {
    echo "<p class='text-center text-muted'>Belum ada dokumen yang diupload.</p>";
}

$stmt->close();
?>
