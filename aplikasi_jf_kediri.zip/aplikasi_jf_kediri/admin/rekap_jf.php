<?php
require_once '../includes/header.php';

// Status validasi options
$status_validasi_options = [
    'Belum Validasi' => 'Belum Validasi',
    'Sudah Validasi' => 'Sudah Validasi'
];

// CRUD Operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if (isset($_POST['action'])) {
            $action = $_POST['action'];
            
            if ($action == 'add') {
                $id_instansi = sanitize_input($_POST['id_instansi']);
                $id_jf = sanitize_input($_POST['id_jf']);
                $id_jenjang = sanitize_input($_POST['id_jenjang']);
                $jumlah_pegawai = intval($_POST['jumlah_pegawai']);
                $dasar_hukum = sanitize_input($_POST['dasar_hukum']);
                $pengakuan_kementerian = sanitize_input($_POST['pengakuan_kementerian']);
                $catatan_tambahan = sanitize_input($_POST['catatan_tambahan']);
                $status_validasi = sanitize_input($_POST['status_validasi']);
                
                if (empty($id_instansi) || empty($id_jf) || empty($id_jenjang)) {
                    throw new Exception("Instansi, Jabatan Fungsional, dan Jenjang harus dipilih!");
                }
                
                $tanggal_validasi = ($status_validasi == 'Sudah Validasi') ? date('Y-m-d H:i:s') : NULL;
                
                $stmt = $conn->prepare("INSERT INTO rekap_jf (id_instansi, id_jf, id_jenjang, jumlah_pegawai, dasar_hukum, pengakuan_kementerian, catatan_tambahan, status_validasi, tanggal_validasi, tanggal_input) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                $stmt->bind_param("iiissssss", $id_instansi, $id_jf, $id_jenjang, $jumlah_pegawai, $dasar_hukum, $pengakuan_kementerian, $catatan_tambahan, $status_validasi, $tanggal_validasi);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data rekap JF berhasil ditambahkan!";
                } else {
                    throw new Exception("Gagal menambahkan data: " . $stmt->error);
                }
                $stmt->close();
                
            } elseif ($action == 'edit') {
                $id_rekap = intval($_POST['id_rekap']);
                $id_instansi = sanitize_input($_POST['id_instansi']);
                $id_jf = sanitize_input($_POST['id_jf']);
                $id_jenjang = sanitize_input($_POST['id_jenjang']);
                $jumlah_pegawai = intval($_POST['jumlah_pegawai']);
                $dasar_hukum = sanitize_input($_POST['dasar_hukum']);
                $pengakuan_kementerian = sanitize_input($_POST['pengakuan_kementerian']);
                $catatan_tambahan = sanitize_input($_POST['catatan_tambahan']);
                $status_validasi = sanitize_input($_POST['status_validasi']);
                
                if (empty($id_instansi) || empty($id_jf) || empty($id_jenjang)) {
                    throw new Exception("OPD, Jabatan Fungsional, dan Jenjang harus dipilih!");
                }
                
                $tanggal_validasi = ($status_validasi == 'Sudah Validasi') ? date('Y-m-d H:i:s') : NULL;
                
                $stmt = $conn->prepare("UPDATE rekap_jf SET id_instansi = ?, id_jf = ?, id_jenjang = ?, jumlah_pegawai = ?, dasar_hukum = ?, pengakuan_kementerian = ?, catatan_tambahan = ?, status_validasi = ?, tanggal_validasi = ? WHERE id_rekap = ?");
                $stmt->bind_param("iiissssssi", $id_instansi, $id_jf, $id_jenjang, $jumlah_pegawai, $dasar_hukum, $pengakuan_kementerian, $catatan_tambahan, $status_validasi, $tanggal_validasi, $id_rekap);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data rekap JF berhasil diperbarui!";
                } else {
                    throw new Exception("Gagal memperbarui data: " . $stmt->error);
                }
                $stmt->close();
                
            } elseif ($action == 'delete') {
                $id_rekap = intval($_POST['id_rekap']);
                
                $stmt = $conn->prepare("DELETE FROM rekap_jf WHERE id_rekap = ?");
                $stmt->bind_param("i", $id_rekap);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data rekap JF berhasil dihapus!";
                } else {
                    throw new Exception("Gagal menghapus data: " . $stmt->error);
                }
                $stmt->close();
            }
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
    }
    
    header("Location: rekap_jf.php");
    exit();
}

// Get data for edit
$data_to_edit = null;
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $edit_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM rekap_jf WHERE id_rekap = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data_to_edit = $result->fetch_assoc();
    $stmt->close();
}

// Get main data with filters
$filter_instansi = isset($_GET['filter_instansi']) ? $_GET['filter_instansi'] : '';
$filter_status = isset($_GET['filter_status']) ? $_GET['filter_status'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$where_conditions = [];
$params = [];
$types = "";

if ($filter_instansi) {
    $where_conditions[] = "r.id_instansi = ?";
    $params[] = $filter_instansi;
    $types .= "i";
}

if ($filter_status) {
    $where_conditions[] = "r.status_validasi = ?";
    $params[] = $filter_status;
    $types .= "s";
}

if ($search) {
    $where_conditions[] = "(i.nama_instansi LIKE ? OR jf.nama_jf LIKE ? OR jj.nama_jenjang LIKE ?)";
    $search_param = "%" . $search . "%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "sss";
}

$where_clause = "";
if (!empty($where_conditions)) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

$sql = "SELECT r.*, i.nama_instansi, jf.nama_jf, jj.nama_jenjang
        FROM rekap_jf r
        JOIN instansi i ON r.id_instansi = i.id_instansi
        JOIN jabatan_fungsional jf ON r.id_jf = jf.id_jf
        JOIN jenjang_jf jj ON r.id_jenjang = jj.id_jenjang
        $where_clause
        ORDER BY i.nama_instansi, jf.nama_jf, jj.nama_jenjang ASC";

if (!empty($params)) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

// Get statistics
$stats = [];
$stats_query = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status_validasi = 'Sudah Validasi' THEN 1 ELSE 0 END) as sudah_validasi,
    SUM(CASE WHEN status_validasi = 'Belum Validasi' THEN 1 ELSE 0 END) as belum_validasi,
    SUM(jumlah_pegawai) as total_pegawai
    FROM rekap_jf";
$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();

// Get chart data for instansi distribution
$instansi_chart_query = "SELECT i.nama_instansi, COUNT(*) as jumlah_rekap, SUM(r.jumlah_pegawai) as total_pegawai
                        FROM rekap_jf r
                        JOIN instansi i ON r.id_instansi = i.id_instansi
                        GROUP BY i.id_instansi, i.nama_instansi
                        ORDER BY total_pegawai DESC
                        LIMIT 10";
$instansi_chart_result = $conn->query($instansi_chart_query);
$instansi_chart_data = [];
while ($row = $instansi_chart_result->fetch_assoc()) {
    $instansi_chart_data[] = $row;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Rekap JF - Sistem JF Kota Kediri</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: 20px;
        }

        .container {
            max-width: 1200px;
        }

        .card {
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            border: none;
            border-radius: 15px;
            margin-bottom: 30px;
        }

        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            border: none;
            padding: 20px;
        }

        .btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }

        .btn-success {
            background: linear-gradient(135deg, #81FBB8 0%, #28C76F 100%);
            border: none;
        }

        .btn-info {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            border: none;
        }

        .btn-warning {
            background: linear-gradient(135deg, #FFD93D 0%, #FF6B6B 100%);
            border: none;
        }

        .btn-danger {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5253 100%);
            border: none;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
        }

        .table th {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-weight: 700;
            border: none;
            color: #495057;
            padding: 15px 12px;
        }

        .table td {
            padding: 15px 12px;
            vertical-align: middle;
            border-color: #f1f3f4;
        }

        .form-control {
            border-radius: 8px;
            border: 2px solid #e0e6ed;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        .badge-sudah {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 8px 15px;
            border-radius: 25px;
            font-size: 11px;
            font-weight: 600;
        }

        .badge-belum {
            background: linear-gradient(135deg, #ffc107 0%, #fd7e14 100%);
            color: white;
            padding: 8px 15px;
            border-radius: 25px;
            font-size: 11px;
            font-weight: 600;
        }

        .alert {
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .stats-card h4 {
            color: #667eea;
            font-weight: 700;
        }
        .stats-card p {
            font-size: 2.5em;
            font-weight: 800;
            color: #333;
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4 text-center" style="color: #495057;">Manajemen Rekap Jabatan Fungsional</h2>

        <?php 
        if (isset($_SESSION['success_message'])) {
            echo "<div class='alert alert-success'>" . $_SESSION['success_message'] . "</div>";
            unset($_SESSION['success_message']);
        }
        if (isset($_SESSION['error_message'])) {
            echo "<div class='alert alert-danger'>" . $_SESSION['error_message'] . "</div>";
            unset($_SESSION['error_message']);
        }
        ?>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>Total Rekap</h4>
                    <p><?php echo $stats['total']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>Sudah Validasi</h4>
                    <p><?php echo $stats['sudah_validasi']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>Belum Validasi</h4>
                    <p><?php echo $stats['belum_validasi']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>Total Pegawai</h4>
                    <p><?php echo $stats['total_pegawai']; ?></p>
                </div>
            </div>
        </div>

        <!-- Chart Container -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Visualisasi Data Rekap JF</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <h6 class="text-center">Status Validasi</h6>
                                <div id="pieChartContainer1" style="position: relative; height:30vh; width:100%;">
                                    <canvas id="validasiPieChart"></canvas>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h6 class="text-center">Top 10 OPD (Jumlah Pegawai)</h6>
                                <div id="barChartContainer" style="position: relative; height:30vh; width:100%;">
                                    <canvas id="instansiBarChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><?php echo $data_to_edit ? 'Edit Data Rekap JF' : 'Tambah Rekap JF Baru'; ?></span>
                <?php if ($data_to_edit): ?>
                    <a href="rekap_jf.php" class="btn btn-sm btn-info">Batal Edit</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <form action="rekap_jf.php" method="POST">
                    <input type="hidden" name="action" value="<?php echo $data_to_edit ? 'edit' : 'add'; ?>">
                    <?php if ($data_to_edit): ?>
                        <input type="hidden" name="id_rekap" value="<?php echo $data_to_edit['id_rekap']; ?>">
                    <?php endif; ?>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="id_instansi">OPD <span class="text-danger">*</span></label>
                            <select class="form-control" id="id_instansi" name="id_instansi" required>
                                <option value="">Pilih OPD</option>
                                <?php
                                $instansi_result = $conn->query("SELECT * FROM instansi ORDER BY nama_instansi ASC");
                                while ($row = $instansi_result->fetch_assoc()) {
                                    $selected = ($data_to_edit && $data_to_edit['id_instansi'] == $row['id_instansi']) ? 'selected' : '';
                                    echo "<option value='" . $row['id_instansi'] . "' " . $selected . ">" . htmlspecialchars($row['nama_instansi']) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="id_jf">Jabatan Fungsional <span class="text-danger">*</span></label>
                            <select class="form-control" id="id_jf" name="id_jf" required>
                                <option value="">Pilih Jabatan Fungsional</option>
                                <?php
                                $jf_result = $conn->query("SELECT * FROM jabatan_fungsional ORDER BY nama_jf ASC");
                                while ($row = $jf_result->fetch_assoc()) {
                                    $selected = ($data_to_edit && $data_to_edit['id_jf'] == $row['id_jf']) ? 'selected' : '';
                                    echo "<option value='" . $row['id_jf'] . "' " . $selected . ">" . htmlspecialchars($row['nama_jf']) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="id_jenjang">Jenjang JF <span class="text-danger">*</span></label>
                            <select class="form-control" id="id_jenjang" name="id_jenjang" required>
                                <option value="">Pilih Jenjang JF</option>
                                <?php
                                $jenjang_result = $conn->query("SELECT * FROM jenjang_jf ORDER BY nama_jenjang ASC");
                                while ($row = $jenjang_result->fetch_assoc()) {
                                    $selected = ($data_to_edit && $data_to_edit['id_jenjang'] == $row['id_jenjang']) ? 'selected' : '';
                                    echo "<option value='" . $row['id_jenjang'] . "' " . $selected . ">" . htmlspecialchars($row['nama_jenjang']) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="jumlah_pegawai">Jumlah Pegawai <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="jumlah_pegawai" name="jumlah_pegawai" value="<?php echo $data_to_edit ? htmlspecialchars($data_to_edit['jumlah_pegawai']) : ''; ?>" required min="0">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="pengakuan_kementerian">Pengakuan Kementerian</label>
                            <select class="form-control" id="pengakuan_kementerian" name="pengakuan_kementerian" required>
                                <option value="Tidak" <?php echo ($data_to_edit && $data_to_edit['pengakuan_kementerian'] == 'Tidak') ? 'selected' : ''; ?>>Tidak</option>
                                <option value="Ya" <?php echo ($data_to_edit && $data_to_edit['pengakuan_kementerian'] == 'Ya') ? 'selected' : ''; ?>>Ya</option>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="status_validasi">Status Validasi</label>
                            <select class="form-control" id="status_validasi" name="status_validasi" required>
                                <?php foreach ($status_validasi_options as $value => $label): ?>
                                    <option value="<?php echo $value; ?>" <?php echo ($data_to_edit && $data_to_edit['status_validasi'] == $value) ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="dasar_hukum">Dasar Hukum</label>
                        <textarea class="form-control" id="dasar_hukum" name="dasar_hukum" rows="3"><?php echo $data_to_edit ? htmlspecialchars($data_to_edit['dasar_hukum']) : ''; ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="catatan_tambahan">Catatan Tambahan</label>
                        <textarea class="form-control" id="catatan_tambahan" name="catatan_tambahan" rows="3"><?php echo $data_to_edit ? htmlspecialchars($data_to_edit['catatan_tambahan']) : ''; ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-save"></i> <?php echo $data_to_edit ? 'Update Data' : 'Tambah Data'; ?>
                    </button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                Daftar Rekap JF
            </div>
            <div class="card-body">
                <form action="rekap_jf.php" method="GET" class="form-inline mb-3">
                    <div class="form-group mr-2">
                        <label for="filter_instansi" class="sr-only">Filter OPD</label>
                        <select class="form-control" id="filter_instansi" name="filter_instansi">
                            <option value="">Semua OPD</option>
                            <?php
                            $instansi_filter_result = $conn->query("SELECT * FROM instansi ORDER BY nama_instansi ASC");
                            while ($row = $instansi_filter_result->fetch_assoc()) {
                                $selected = ($filter_instansi == $row['id_instansi']) ? 'selected' : '';
                                echo "<option value='" . $row['id_instansi'] . "' " . $selected . ">" . htmlspecialchars($row['nama_instansi']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group mr-2">
                        <label for="filter_status" class="sr-only">Filter Status Validasi</label>
                        <select class="form-control" id="filter_status" name="filter_status">
                            <option value="">Semua Status</option>
                            <?php foreach ($status_validasi_options as $value => $label): ?>
                                <option value="<?php echo $value; ?>" <?php echo ($filter_status == $value) ? 'selected' : ''; ?>>
                                    <?php echo $label; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group mr-2">
                        <label for="search" class="sr-only">Cari</label>
                        <input type="text" class="form-control" id="search" name="search" placeholder="Cari..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                    <a href="rekap_jf.php" class="btn btn-secondary ml-2"><i class="fas fa-sync-alt"></i> Reset</a>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>OPD</th>
                                <th>Jabatan Fungsional</th>
                                <th>Jenjang</th>
                                <th>Jumlah</th>
                                <th>Status Validasi</th>
                                <th>Pengakuan Kemen.</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result->num_rows > 0): ?>
                                <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_instansi']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_jf']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_jenjang']); ?></td>
                                        <td><?php echo htmlspecialchars($row['jumlah_pegawai']); ?></td>
                                        <td>
                                            <span class="badge <?php echo ($row['status_validasi'] == 'Sudah Validasi') ? 'badge-sudah' : 'badge-belum'; ?>">
                                                <?php echo htmlspecialchars($row['status_validasi']); ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($row['pengakuan_kementerian']); ?></td>
                                        <td>
                                            <a href="rekap_jf.php?action=edit&id=<?php echo $row['id_rekap']; ?>" class="btn btn-sm btn-warning mb-1" title="Edit"><i class="fas fa-edit"></i></a>
                                            <button type="button" class="btn btn-sm btn-danger mb-1" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo $row['id_rekap']; ?>" title="Hapus"><i class="fas fa-trash"></i></button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="8" class="text-center">Tidak ada data rekap JF.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Apakah Anda yakin ingin menghapus data rekap JF ini?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <form id="deleteForm" method="POST" action="rekap_jf.php">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id_rekap" id="delete_id">
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $('#deleteModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);
            modal.find('#delete_id').val(id);
        });

        // Initialize charts
        document.addEventListener('DOMContentLoaded', function() {
            // Status Validasi Pie Chart
            const validasiCtx = document.getElementById('validasiPieChart').getContext('2d');
            const validasiPieChart = new Chart(validasiCtx, {
                type: 'pie',
                data: {
                    labels: ['Sudah Validasi', 'Belum Validasi'],
                    datasets: [{
                        label: 'Jumlah Rekap',
                        data: [<?php echo $stats['sudah_validasi']; ?>, <?php echo $stats['belum_validasi']; ?>],
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.8)',
                            'rgba(255, 205, 86, 0.8)'
                        ],
                        borderColor: [
                            'rgba(75, 192, 192, 1)',
                            'rgba(255, 205, 86, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.label + ': ' + context.parsed;
                                }
                            }
                        }
                    }
                }
            });

            // Instansi Bar Chart
            const instansiCtx = document.getElementById('instansiBarChart').getContext('2d');
            const instansiBarChart = new Chart(instansiCtx, {
                type: 'bar',
                data: {
                    labels: [
                        <?php 
                        foreach ($instansi_chart_data as $data) {
                            echo "'" . addslashes($data['nama_instansi']) . "',";
                        }
                        ?>
                    ],
                    datasets: [{
                        label: 'Jumlah Pegawai',
                        data: [
                            <?php 
                            foreach ($instansi_chart_data as $data) {
                                echo $data['total_pegawai'] . ",";
                            }
                            ?>
                        ],
                        backgroundColor: 'rgba(54, 162, 235, 0.8)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return 'Jumlah Pegawai: ' + context.parsed.y;
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>
