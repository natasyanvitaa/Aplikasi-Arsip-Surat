<?php
include '../includes/header.php';
?>

<h2>Selamat Datang di Dashboard Admin</h2>
<p>Gunakan menu navigasi di atas untuk mengelola data Jabatan Fungsional.</p>

<div class="dashboard-stats">
    <div class="stat-box">
        <h3>Total OPD</h3>
        <?php
        $result = $conn->query("SELECT COUNT(*) AS total FROM instansi");
        $row = $result->fetch_assoc();
        echo "<p>" . $row['total'] . "</p>";
        ?>
    </div>
    <div class="stat-box">
        <h3>Total Jabatan Fungsional</h3>
        <?php
        $result = $conn->query("SELECT COUNT(*) AS total FROM jabatan_fungsional");
        $row = $result->fetch_assoc();
        echo "<p>" . $row['total'] . "</p>";
        ?>
    </div>
    <div class="stat-box">
        <h3>Total Pegawai JF</h3>
        <?php
        $result = $conn->query("SELECT COUNT(*) AS total FROM pegawai WHERE id_jf IS NOT NULL");
        $row = $result->fetch_assoc();
        echo "<p>" . $row['total'] . "</p>";
        ?>
    </div>
    <div class="stat-box">
        <h3>Rekap Belum Validasi</h3>
        <?php
        $result = $conn->query("SELECT COUNT(*) AS total FROM rekap_jf WHERE status_validasi = 'Belum Validasi'");
        $row = $result->fetch_assoc();
        echo "<p>" . $row['total'] . "</p>";
        ?>
    </div>
</div>

<?php
include '../includes/footer.php';
?>
