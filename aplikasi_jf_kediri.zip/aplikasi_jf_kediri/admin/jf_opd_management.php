<?php
require_once '../includes/header.php';

// Status tracking options
$status_tracking_options = [
    0 => 'Belum Dihitung',
    1 => 'Sedang Dihitung',
    2 => 'Diminta Rekomendasi',
    3 => 'Telah Diminta Rekomendasi',
    4 => 'Diminta Validasi Menpan',
    5 => 'Sudah Divalidasi Menpan',
    6 => 'Dibuatkan Dasar Hukum'
];

// CRUD Operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if (isset($_POST['action'])) {
            $action = $_POST['action'];
            
            if ($action == 'add') {
                $id_jf = intval($_POST['id_jf']);
                $id_instansi = intval($_POST['id_instansi']);
                $id_jenjang = intval($_POST['id_jenjang']);
                $jumlah_pegawai = intval($_POST['jumlah_pegawai']);
                $status_tracking = intval($_POST['status_tracking']);
                $catatan = sanitize_input($_POST['catatan']);
                $dasar_hukum = sanitize_input($_POST['dasar_hukum']);
                
                if (empty($id_jf) || empty($id_instansi)) {
                    throw new Exception("JF dan Instansi harus dipilih!");
                }
                
                // Check for duplicate combination
                $check_stmt = $conn->prepare("SELECT id_tracking FROM jf_opd_tracking WHERE id_jf = ? AND id_instansi = ? AND id_jenjang = ?");
                $check_stmt->bind_param("iii", $id_jf, $id_instansi, $id_jenjang);
                $check_stmt->execute();
                if ($check_stmt->get_result()->num_rows > 0) {
                    throw new Exception("Kombinasi JF, Instansi, dan Jenjang sudah ada!");
                }
                $check_stmt->close();
                
                $tanggal_mulai = ($status_tracking > 0) ? date('Y-m-d H:i:s') : NULL;
                $tanggal_selesai = ($status_tracking == 6) ? date('Y-m-d H:i:s') : NULL;
                
                $stmt = $conn->prepare("INSERT INTO jf_opd_tracking (id_jf, id_instansi, id_jenjang, jumlah_pegawai, status_tracking, tanggal_mulai, tanggal_selesai, catatan, dasar_hukum, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
                $stmt->bind_param("iiiissssss", $id_jf, $id_instansi, $id_jenjang, $jumlah_pegawai, $status_tracking, $tanggal_mulai, $tanggal_selesai, $catatan, $dasar_hukum);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data tracking JF-OPD berhasil ditambahkan!";
                } else {
                    throw new Exception("Gagal menambahkan data: " . $stmt->error);
                }
                $stmt->close();
                
            } elseif ($action == 'edit') {
                $id_tracking = intval($_POST['id_tracking']);
                $id_jf = intval($_POST['id_jf']);
                $id_instansi = intval($_POST['id_instansi']);
                $id_jenjang = intval($_POST['id_jenjang']);
                $jumlah_pegawai = intval($_POST['jumlah_pegawai']);
                $status_tracking = intval($_POST['status_tracking']);
                $catatan = sanitize_input($_POST['catatan']);
                $dasar_hukum = sanitize_input($_POST['dasar_hukum']);
                
                if (empty($id_jf) || empty($id_instansi)) {
                    throw new Exception("JF dan Instansi harus dipilih!");
                }
                
                // Check for duplicate combination (exclude current record)
                $check_stmt = $conn->prepare("SELECT id_tracking FROM jf_opd_tracking WHERE id_jf = ? AND id_instansi = ? AND id_jenjang = ? AND id_tracking != ?");
                $check_stmt->bind_param("iiii", $id_jf, $id_instansi, $id_jenjang, $id_tracking);
                $check_stmt->execute();
                if ($check_stmt->get_result()->num_rows > 0) {
                    throw new Exception("Kombinasi JF, Instansi, dan Jenjang sudah ada!");
                }
                $check_stmt->close();
                
                // Get current data to check status change
                $current_stmt = $conn->prepare("SELECT status_tracking, tanggal_mulai FROM jf_opd_tracking WHERE id_tracking = ?");
                $current_stmt->bind_param("i", $id_tracking);
                $current_stmt->execute();
                $current_data = $current_stmt->get_result()->fetch_assoc();
                $current_stmt->close();
                
                $tanggal_mulai = $current_data['tanggal_mulai'];
                $tanggal_selesai = NULL;
                
                // Set tanggal_mulai if status changes from 0 to > 0
                if ($current_data['status_tracking'] == 0 && $status_tracking > 0) {
                    $tanggal_mulai = date('Y-m-d H:i:s');
                }
                
                // Set tanggal_selesai if status is 6
                if ($status_tracking == 6) {
                    $tanggal_selesai = date('Y-m-d H:i:s');
                }
                
                $stmt = $conn->prepare("UPDATE jf_opd_tracking SET id_jf = ?, id_instansi = ?, id_jenjang = ?, jumlah_pegawai = ?, status_tracking = ?, tanggal_mulai = ?, tanggal_selesai = ?, catatan = ?, dasar_hukum = ?, updated_at = NOW() WHERE id_tracking = ?");
                $stmt->bind_param("iiiisssssi", $id_jf, $id_instansi, $id_jenjang, $jumlah_pegawai, $status_tracking, $tanggal_mulai, $tanggal_selesai, $catatan, $dasar_hukum, $id_tracking);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data tracking JF-OPD berhasil diperbarui!";
                } else {
                    throw new Exception("Gagal memperbarui data: " . $stmt->error);
                }
                $stmt->close();
                
            } elseif ($action == 'delete') {
                $id_tracking = intval($_POST['id_tracking']);
                
                // Delete related documents first
                $doc_stmt = $conn->prepare("SELECT nama_file FROM dokumen_pendukung WHERE id_tracking = ?");
                $doc_stmt->bind_param("i", $id_tracking);
                $doc_stmt->execute();
                $doc_result = $doc_stmt->get_result();
                while ($doc_row = $doc_result->fetch_assoc()) {
                    delete_file($doc_row['nama_file']);
                }
                $doc_stmt->close();
                
                $stmt = $conn->prepare("DELETE FROM jf_opd_tracking WHERE id_tracking = ?");
                $stmt->bind_param("i", $id_tracking);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data tracking JF-OPD berhasil dihapus!";
                } else {
                    throw new Exception("Gagal menghapus data: " . $stmt->error);
                }
                $stmt->close();
                
            } elseif ($action == 'upload_document') {
                $id_tracking = intval($_POST['id_tracking']);
                $keterangan = sanitize_input($_POST['keterangan']);
                
                if (isset($_FILES['dokumen']) && $_FILES['dokumen']['error'] == UPLOAD_ERR_OK) {
                    $upload_result = upload_file($_FILES['dokumen']);
                    
                    if ($upload_result['success']) {
                        $stmt = $conn->prepare("INSERT INTO dokumen_pendukung (id_tracking, nama_file, nama_asli, ukuran_file, tipe_file, path_file, keterangan, uploaded_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                        $path_file = 'uploads/dokumen_pendukung/' . $upload_result['filename'];
                        $uploaded_by = $_SESSION['username'] ?? 'System';
                        
                        $stmt->bind_param("issiisss", $id_tracking, $upload_result['filename'], $_FILES['dokumen']['name'], $_FILES['dokumen']['size'], $_FILES['dokumen']['type'], $path_file, $keterangan, $uploaded_by);
                        
                        if ($stmt->execute()) {
                            $_SESSION['success_message'] = "Dokumen berhasil diupload!";
                        } else {
                            delete_file($upload_result['filename']);
                            throw new Exception("Gagal menyimpan data dokumen: " . $stmt->error);
                        }
                        $stmt->close();
                    } else {
                        throw new Exception($upload_result['message']);
                    }
                } else {
                    throw new Exception("File dokumen harus dipilih!");
                }
            }
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
    }
    
    header("Location: jf_opd_management.php");
    exit();
}

// Get data for edit
$data_to_edit = null;
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $edit_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM jf_opd_tracking WHERE id_tracking = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data_to_edit = $result->fetch_assoc();
    $stmt->close();
}

// Get main data with filters
$filter_instansi = isset($_GET['filter_instansi']) ? $_GET['filter_instansi'] : '';
$filter_jf = isset($_GET['filter_jf']) ? $_GET['filter_jf'] : '';
$filter_status = isset($_GET['filter_status']) ? $_GET['filter_status'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$where_conditions = [];
$params = [];
$types = "";

if ($filter_instansi) {
    $where_conditions[] = "t.id_instansi = ?";
    $params[] = $filter_instansi;
    $types .= "i";
}

if ($filter_jf) {
    $where_conditions[] = "t.id_jf = ?";
    $params[] = $filter_jf;
    $types .= "i";
}

if ($filter_status !== '') {
    $where_conditions[] = "t.status_tracking = ?";
    $params[] = $filter_status;
    $types .= "i";
}

if ($search) {
    $where_conditions[] = "(i.nama_instansi LIKE ? OR jf.nama_jf LIKE ? OR jj.nama_jenjang LIKE ?)";
    $search_param = "%" . $search . "%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "sss";
}

$where_clause = "";
if (!empty($where_conditions)) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

$sql = "SELECT t.*, i.nama_instansi, jf.nama_jf, jf.kategori, jj.nama_jenjang,
        (SELECT COUNT(*) FROM dokumen_pendukung dp WHERE dp.id_tracking = t.id_tracking) as jumlah_dokumen
        FROM jf_opd_tracking t
        JOIN instansi i ON t.id_instansi = i.id_instansi
        JOIN jabatan_fungsional jf ON t.id_jf = jf.id_jf
        LEFT JOIN jenjang_jf jj ON t.id_jenjang = jj.id_jenjang
        $where_clause
        ORDER BY i.nama_instansi, jf.nama_jf, jj.nama_jenjang ASC";

if (!empty($params)) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

// Get statistics
$stats = [];
$stats_query = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status_tracking = 0 THEN 1 ELSE 0 END) as belum_dihitung,
    SUM(CASE WHEN status_tracking = 1 THEN 1 ELSE 0 END) as sedang_dihitung,
    SUM(CASE WHEN status_tracking = 2 THEN 1 ELSE 0 END) as diminta_rekomendasi,
    SUM(CASE WHEN status_tracking = 3 THEN 1 ELSE 0 END) as telah_diminta_rekomendasi,
    SUM(CASE WHEN status_tracking = 4 THEN 1 ELSE 0 END) as diminta_validasi_menpan,
    SUM(CASE WHEN status_tracking = 5 THEN 1 ELSE 0 END) as sudah_divalidasi_menpan,
    SUM(CASE WHEN status_tracking = 6 THEN 1 ELSE 0 END) as dibuatkan_dasar_hukum,
    SUM(jumlah_pegawai) as total_pegawai
    FROM jf_opd_tracking";
$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();

// Get chart data for status distribution
$status_chart_data = [];
foreach ($status_tracking_options as $status_code => $status_label) {
    $count_query = "SELECT COUNT(*) as count FROM jf_opd_tracking WHERE status_tracking = $status_code";
    $count_result = $conn->query($count_query);
    $count = $count_result->fetch_assoc()['count'];
    $status_chart_data[] = ['label' => $status_label, 'count' => $count];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen JF-OPD - Sistem JF Kota Kediri</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: 20px;
        }

        .container {
            max-width: 1400px;
        }

        .card {
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            border: none;
            border-radius: 15px;
            margin-bottom: 30px;
        }

        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            border: none;
            padding: 20px;
        }

        .btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }

        .btn-success {
            background: linear-gradient(135deg, #81FBB8 0%, #28C76F 100%);
            border: none;
        }

        .btn-info {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            border: none;
        }

        .btn-warning {
            background: linear-gradient(135deg, #FFD93D 0%, #FF6B6B 100%);
            border: none;
        }

        .btn-danger {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5253 100%);
            border: none;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
        }

        .table th {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-weight: 700;
            border: none;
            color: #495057;
            padding: 15px 12px;
        }

        .table td {
            padding: 15px 12px;
            vertical-align: middle;
            border-color: #f1f3f4;
        }

        .form-control {
            border-radius: 8px;
            border: 2px solid #e0e6ed;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        .alert {
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .stats-card h4 {
            color: #667eea;
            font-weight: 700;
            font-size: 0.9rem;
        }
        .stats-card p {
            font-size: 2em;
            font-weight: 800;
            color: #333;
            margin: 0;
        }

        .upload-area {
            border: 2px dashed #667eea;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            background: #f8f9ff;
            transition: all 0.3s ease;
        }

        .upload-area:hover {
            border-color: #764ba2;
            background: #f0f2ff;
        }

        .file-list {
            max-height: 200px;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4 text-center" style="color: #495057;">Manajemen JF-OPD</h2>

        <?php 
        if (isset($_SESSION['success_message'])) {
            echo "<div class='alert alert-success'>" . $_SESSION['success_message'] . "</div>";
            unset($_SESSION['success_message']);
        }
        if (isset($_SESSION['error_message'])) {
            echo "<div class='alert alert-danger'>" . $_SESSION['error_message'] . "</div>";
            unset($_SESSION['error_message']);
        }
        ?>

        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-2">
                <div class="stats-card">
                    <h4>Total Tracking</h4>
                    <p><?php echo $stats['total']; ?></p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stats-card">
                    <h4>Belum Dihitung</h4>
                    <p><?php echo $stats['belum_dihitung']; ?></p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stats-card">
                    <h4>Sedang Proses</h4>
                    <p><?php echo $stats['sedang_dihitung']; ?></p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stats-card">
                    <h4>Validasi Menpan</h4>
                    <p><?php echo $stats['sudah_divalidasi_menpan']; ?></p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stats-card">
                    <h4>Selesai</h4>
                    <p><?php echo $stats['dibuatkan_dasar_hukum']; ?></p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="stats-card">
                    <h4>Total Pegawai</h4>
                    <p><?php echo $stats['total_pegawai']; ?></p>
                </div>
            </div>
        </div>

        <!-- Chart Container -->
        <div class="row mb-4">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Distribusi Status Tracking JF-OPD</h5>
                    </div>
                    <div class="card-body">
                        <div id="pieChartContainer" style="position: relative; height:40vh; width:100%;">
                            <canvas id="statusPieChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Export Data</h5>
                    </div>
                    <div class="card-body text-center">
                        <a href="export_handler.php?type=excel&table=jf_opd" class="btn btn-success btn-block mb-2">
                            <i class="fas fa-file-excel"></i> Export Excel
                        </a>
                        <a href="export_handler.php?type=pdf&table=jf_opd" class="btn btn-danger btn-block">
                            <i class="fas fa-file-pdf"></i> Export PDF
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Add/Edit -->
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><?php echo $data_to_edit ? 'Edit Data JF-OPD' : 'Tambah Data JF-OPD Baru'; ?></span>
                <?php if ($data_to_edit): ?>
                    <a href="jf_opd_management.php" class="btn btn-sm btn-info">Batal Edit</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <form action="jf_opd_management.php" method="POST">
                    <input type="hidden" name="action" value="<?php echo $data_to_edit ? 'edit' : 'add'; ?>">
                    <?php if ($data_to_edit): ?>
                        <input type="hidden" name="id_tracking" value="<?php echo $data_to_edit['id_tracking']; ?>">
                    <?php endif; ?>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="id_jf">Jabatan Fungsional <span class="text-danger">*</span></label>
                            <select class="form-control" id="id_jf" name="id_jf" required>
                                <option value="">Pilih Jabatan Fungsional</option>
                                <?php
                                $jf_result = $conn->query("SELECT * FROM jabatan_fungsional WHERE status_aktif = 'aktif' ORDER BY nama_jf ASC");
                                while ($row = $jf_result->fetch_assoc()) {
                                    $selected = ($data_to_edit && $data_to_edit['id_jf'] == $row['id_jf']) ? 'selected' : '';
                                    echo "<option value='" . $row['id_jf'] . "' " . $selected . ">" . htmlspecialchars($row['nama_jf']) . " (" . ucfirst($row['kategori']) . ")</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="id_instansi">Instansi/OPD <span class="text-danger">*</span></label>
                            <select class="form-control" id="id_instansi" name="id_instansi" required>
                                <option value="">Pilih Instansi/OPD</option>
                                <?php
                                $instansi_result = $conn->query("SELECT * FROM instansi ORDER BY nama_instansi ASC");
                                while ($row = $instansi_result->fetch_assoc()) {
                                    $selected = ($data_to_edit && $data_to_edit['id_instansi'] == $row['id_instansi']) ? 'selected' : '';
                                    echo "<option value='" . $row['id_instansi'] . "' " . $selected . ">" . htmlspecialchars($row['nama_instansi']) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label for="id_jenjang">Jenjang JF</label>
                            <select class="form-control" id="id_jenjang" name="id_jenjang">
                                <option value="">Pilih Jenjang JF</option>
                                <?php
                                $jenjang_result = $conn->query("SELECT * FROM jenjang_jf ORDER BY urutan ASC");
                                while ($row = $jenjang_result->fetch_assoc()) {
                                    $selected = ($data_to_edit && $data_to_edit['id_jenjang'] == $row['id_jenjang']) ? 'selected' : '';
                                    echo "<option value='" . $row['id_jenjang'] . "' " . $selected . ">" . htmlspecialchars($row['nama_jenjang']) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label for="jumlah_pegawai">Jumlah Pegawai</label>
                            <input type="number" class="form-control" id="jumlah_pegawai" name="jumlah_pegawai" value="<?php echo $data_to_edit ? htmlspecialchars($data_to_edit['jumlah_pegawai']) : '0'; ?>" min="0">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="status_tracking">Status Tracking <span class="text-danger">*</span></label>
                            <select class="form-control" id="status_tracking" name="status_tracking" required>
                                <?php foreach ($status_tracking_options as $value => $label): ?>
                                    <option value="<?php echo $value; ?>" <?php echo ($data_to_edit && $data_to_edit['status_tracking'] == $value) ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group col-md-4">
                            <label>&nbsp;</label>
                            <button type="submit" class="btn btn-primary btn-block">
                                <i class="fas fa-save"></i> <?php echo $data_to_edit ? 'Update Data' : 'Tambah Data'; ?>
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="catatan">Catatan</label>
                        <textarea class="form-control" id="catatan" name="catatan" rows="2"><?php echo $data_to_edit ? htmlspecialchars($data_to_edit['catatan']) : ''; ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="dasar_hukum">Dasar Hukum</label>
                        <textarea class="form-control" id="dasar_hukum" name="dasar_hukum" rows="2"><?php echo $data_to_edit ? htmlspecialchars($data_to_edit['dasar_hukum']) : ''; ?></textarea>
                    </div>
                </form>
            </div>
        </div>

        <!-- Data Table -->
        <div class="card">
            <div class="card-header">
                Daftar JF-OPD Tracking
            </div>
            <div class="card-body">
                <!-- Filters -->
                <form action="jf_opd_management.php" method="GET" class="form-inline mb-3">
                    <div class="form-group mr-2">
                        <select class="form-control" name="filter_instansi">
                            <option value="">Semua Instansi</option>
                            <?php
                            $instansi_filter_result = $conn->query("SELECT * FROM instansi ORDER BY nama_instansi ASC");
                            while ($row = $instansi_filter_result->fetch_assoc()) {
                                $selected = ($filter_instansi == $row['id_instansi']) ? 'selected' : '';
                                echo "<option value='" . $row['id_instansi'] . "' " . $selected . ">" . htmlspecialchars($row['nama_instansi']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group mr-2">
                        <select class="form-control" name="filter_jf">
                            <option value="">Semua JF</option>
                            <?php
                            $jf_filter_result = $conn->query("SELECT * FROM jabatan_fungsional WHERE status_aktif = 'aktif' ORDER BY nama_jf ASC");
                            while ($row = $jf_filter_result->fetch_assoc()) {
                                $selected = ($filter_jf == $row['id_jf']) ? 'selected' : '';
                                echo "<option value='" . $row['id_jf'] . "' " . $selected . ">" . htmlspecialchars($row['nama_jf']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group mr-2">
                        <select class="form-control" name="filter_status">
                            <option value="">Semua Status</option>
                            <?php foreach ($status_tracking_options as $value => $label): ?>
                                <option value="<?php echo $value; ?>" <?php echo ($filter_status == $value) ? 'selected' : ''; ?>>
                                    <?php echo $label; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group mr-2">
                        <input type="text" class="form-control" name="search" placeholder="Cari..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                    <a href="jf_opd_management.php" class="btn btn-secondary ml-2"><i class="fas fa-sync-alt"></i> Reset</a>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Instansi/OPD</th>
                                <th>Jabatan Fungsional</th>
                                <th>Jenjang</th>
                                <th>Jumlah Pegawai</th>
                                <th>Status</th>
                                <th>Dokumen</th>
                                <th>Tanggal Update</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result->num_rows > 0): ?>
                                <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_instansi']); ?></td>
                                        <td>
                                            <?php echo htmlspecialchars($row['nama_jf']); ?>
                                            <br><small class="text-muted"><?php echo ucfirst($row['kategori']); ?></small>
                                        </td>
                                        <td><?php echo htmlspecialchars($row['nama_jenjang'] ?? '-'); ?></td>
                                        <td><?php echo htmlspecialchars($row['jumlah_pegawai']); ?></td>
                                        <td>
                                            <span class="badge <?php echo get_status_badge_class($row['status_tracking']); ?>">
                                                <?php echo get_status_tracking_label($row['status_tracking']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="badge badge-info"><?php echo $row['jumlah_dokumen']; ?> file</span>
                                            <button type="button" class="btn btn-sm btn-outline-primary ml-1" data-toggle="modal" data-target="#uploadModal" data-id="<?php echo $row['id_tracking']; ?>">
                                                <i class="fas fa-upload"></i>
                                            </button>
                                            <?php if ($row['jumlah_dokumen'] > 0): ?>
                                                <button type="button" class="btn btn-sm btn-outline-info ml-1" data-toggle="modal" data-target="#viewDocModal" data-id="<?php echo $row['id_tracking']; ?>">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo format_tanggal($row['updated_at']); ?></td>
                                        <td>
                                            <a href="jf_opd_management.php?action=edit&id=<?php echo $row['id_tracking']; ?>" class="btn btn-sm btn-warning mb-1" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <button type="button" class="btn btn-sm btn-danger mb-1" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo $row['id_tracking']; ?>" title="Hapus">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center">Tidak ada data JF-OPD tracking.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Upload Document Modal -->
    <div class="modal fade" id="uploadModal" tabindex="-1" role="dialog" aria-labelledby="uploadModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="uploadModalLabel">Upload Dokumen Pendukung</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="jf_opd_management.php" method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="upload_document">
                        <input type="hidden" name="id_tracking" id="upload_id_tracking">
                        
                        <div class="form-group">
                            <label for="dokumen">Pilih Dokumen (PDF, DOC, DOCX)</label>
                            <div class="upload-area">
                                <input type="file" class="form-control-file" id="dokumen" name="dokumen" accept=".pdf,.doc,.docx" required>
                                <p class="mt-2 mb-0"><i class="fas fa-cloud-upload-alt fa-2x"></i></p>
                                <p class="text-muted">Drag & drop file atau klik untuk memilih</p>
                                <small class="text-muted">Maksimal 10MB</small>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="keterangan">Keterangan</label>
                            <textarea class="form-control" id="keterangan" name="keterangan" rows="3" placeholder="Keterangan dokumen..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-upload"></i> Upload
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- View Documents Modal -->
    <div class="modal fade" id="viewDocModal" tabindex="-1" role="dialog" aria-labelledby="viewDocModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewDocModalLabel">Dokumen Pendukung</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div id="documentList" class="file-list">
                        <!-- Documents will be loaded here via AJAX -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Apakah Anda yakin ingin menghapus data tracking JF-OPD ini? Semua dokumen terkait juga akan dihapus.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <form id="deleteForm" method="POST" action="jf_opd_management.php">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id_tracking" id="delete_id">
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Modal handlers
        $('#uploadModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);
            modal.find('#upload_id_tracking').val(id);
        });

        $('#deleteModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);
            modal.find('#delete_id').val(id);
        });

        $('#viewDocModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);
            
            // Load documents via AJAX
            $.get('get_documents.php?id_tracking=' + id, function(data) {
                modal.find('#documentList').html(data);
            });
        });

        // Initialize pie chart
        document.addEventListener('DOMContentLoaded', function() {
            const ctx = document.getElementById('statusPieChart').getContext('2d');
            const statusPieChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: [
                        <?php 
                        foreach ($status_chart_data as $data) {
                            echo "'" . addslashes($data['label']) . "',";
                        }
                        ?>
                    ],
                    datasets: [{
                        label: 'Jumlah',
                        data: [
                            <?php 
                            foreach ($status_chart_data as $data) {
                                echo $data['count'] . ",";
                            }
                            ?>
                        ],
                        backgroundColor: [
                            'rgba(108, 117, 125, 0.8)',
                            'rgba(23, 162, 184, 0.8)',
                            'rgba(255, 193, 7, 0.8)',
                            'rgba(0, 123, 255, 0.8)',
                            'rgba(220, 53, 69, 0.8)',
                            'rgba(40, 167, 69, 0.8)',
                            'rgba(52, 58, 64, 0.8)'
                        ],
                        borderColor: [
                            'rgba(108, 117, 125, 1)',
                            'rgba(23, 162, 184, 1)',
                            'rgba(255, 193, 7, 1)',
                            'rgba(0, 123, 255, 1)',
                            'rgba(220, 53, 69, 1)',
                            'rgba(40, 167, 69, 1)',
                            'rgba(52, 58, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.label + ': ' + context.parsed;
                                }
                            }
                        }
                    }
                }
            });
        });

        // File upload drag and drop
        const uploadArea = document.querySelector('.upload-area');
        const fileInput = document.querySelector('#dokumen');

        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#764ba2';
            uploadArea.style.background = '#f0f2ff';
        });

        uploadArea.addEventListener('dragleave', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#667eea';
            uploadArea.style.background = '#f8f9ff';
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.style.borderColor = '#667eea';
            uploadArea.style.background = '#f8f9ff';
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
            }
        });

        uploadArea.addEventListener('click', () => {
            fileInput.click();
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>
