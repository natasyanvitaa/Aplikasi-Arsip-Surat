// Fix for manual input function in Pembina Jabatan Fungsional
$(document).ready(function() {
    // Handle Pembina JF dropdown change
    $('#pembina_jf').change(function() {
        var selectedValue = $(this).val();
        if (selectedValue === 'Lainnya') {
            $('#pembina_jf_manual').show().attr('required', true).focus();
            $('#pembina_jf').removeAttr('required');
        } else {
            $('#pembina_jf_manual').hide().removeAttr('required');
            $('#pembina_jf').attr('required', true);
        }
    });

    // Handle Nama JF dropdown change
    $('#nama_jf').change(function() {
        var selectedValue = $(this).val();
        if (selectedValue === 'Lainnya') {
            $('#nama_jf_manual').show().attr('required', true).focus();
            $('#nama_jf').removeAttr('required');
        } else {
            $('#nama_jf_manual').hide().removeAttr('required');
            $('#nama_jf').attr('required', true);
        }
    });

    // Handle form submission with manual inputs
    $('form').submit(function(e) {
        var pembina_jf_select = $('#pembina_jf').val();
        var pembina_jf_manual = $('#pembina_jf_manual').val();
        
        if (pembina_jf_select === 'Lainnya') {
            if (!pembina_jf_manual.trim()) {
                alert('Pembina JF harus diisi!');
                e.preventDefault();
                return false;
            }
            // Set the manual value to the hidden input
            $('<input>').attr({
                type: 'hidden',
                name: 'pembina_jf',
                value: pembina_jf_manual
            }).appendTo('form');
        }

        var nama_jf_select = $('#nama_jf').val();
        var nama_jf_manual = $('#nama_jf_manual').val();
        
        if (nama_jf_select === 'Lainnya') {
            if (!nama_jf_manual.trim()) {
                alert('Nama JF harus diisi!');
                e.preventDefault();
                return false;
            }
            // Set the manual value to the hidden input
            $('<input>').attr({
                type: 'hidden',
                name: 'nama_jf',
                value: nama_jf_manual
            }).appendTo('form');
        }
    });

    // Initialize on page load
    function initializeManualInputs() {
        // Check if we have manual values on page load
        var pembinaManualValue = $('#pembina_jf_manual').val();
        if (pembinaManualValue && pembinaManualValue.trim() && !$('#pembina_jf option[value="' + pembinaManualValue + '"]').length) {
            $('#pembina_jf').val('Lainnya').trigger('change');
        }

        var namaManualValue = $('#nama_jf_manual').val();
        if (namaManualValue && namaManualValue.trim() && !$('#nama_jf option[value="' + namaManualValue + '"]').length) {
            $('#nama_jf').val('Lainnya').trigger('change');
        }
    }

    initializeManualInputs();
});

// Alternative function for togglePembinaManual if needed
function togglePembinaManual() {
    var selectedValue = document.getElementById('pembina_jf').value;
    var manualInput = document.getElementById('pembina_jf_manual');
    
    if (selectedValue === 'Lainnya') {
        manualInput.style.display = 'block';
        manualInput.required = true;
        manualInput.focus();
    } else {
        manualInput.style.display = 'none';
        manualInput.required = false;
    }
}
