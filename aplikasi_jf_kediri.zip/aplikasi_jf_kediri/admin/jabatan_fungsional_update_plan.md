# Update Plan: Add Pembina Jabatan Fungsional & Jabatan Fungsional Columns

## Information Gathered

### Current Database Structure
- Table: `jabatan_fungsional`
- Current columns: id_jf, kode_jf, nama_jf, kategori, pendidikan_minimal, tugas_pokok, fungsi, deskripsi, peraturan, status_validasi, created_at, updated_at
- Missing: pembina_jabatan_fungsional and jabatan_fungsional columns

### Requirements
1. Add two new columns to store:
   - `pembina_jabatan_fungsional`: Institution that oversees the functional position
   - `jabatan_fungsional`: Specific functional position name
2. Provide clickable options (dropdown/select) instead of text input
3. Use the provided 54 institutions list as data source
4. Ensure backward compatibility with existing data

## Plan

### 1. Database Schema Update
**File:** `add_pembina_jf_columns.sql`
- Add two new VARCHAR columns to jabatan_fungsional table
- Set appropriate length (255 characters)
- Allow NULL values for backward compatibility

### 2. PHP Form Updates
**File:** `admin/jabatan_fungsional.php`
- Add new form fields in both add and edit forms
- Create dropdown select elements with options from the 54 institutions
- Update form validation and processing
- Update SQL queries for CRUD operations

### 3. Data Structure for Dropdowns
**File:** `includes/instansi_data.php` (new file)
- Create arrays for institutions and their functional positions
- Organize data hierarchically for easy dropdown population

### 4. JavaScript Enhancement
**File:** `assets/js/jabatan_fungsional.js` (new file)
- Dynamic dropdown population based on selected institution
- Filter functional positions based on selected pembina

## Dependent Files to be Edited

1. **admin/jabatan_fungsional.php**
   - Add new form fields
   - Update SQL queries
   - Add dropdown select elements

2. **add_pembina_jf_columns.sql**
   - Database schema update

3. **includes/instansi_data.php** (new)
   - Store institution and functional position data

4. **assets/js/jabatan_fungsional.js** (new)
   - Dynamic dropdown functionality

## Implementation Steps

### Step 1: Database Schema Update
```sql
ALTER TABLE jabatan_fungsional 
ADD COLUMN pembina_jabatan_fungsional VARCHAR(255) NULL,
ADD COLUMN jabatan_fungsional VARCHAR(255) NULL;
```

### Step 2: Create Data Structure
Create arrays for institutions and functional positions based on the 54 provided institutions.

### Step 3: Update Forms
Add dropdown selects in both add and edit forms with proper validation.

### Step 4: Update Processing
Modify CRUD operations to handle new columns.

### Step 5: Add JavaScript
Implement dynamic dropdown functionality.

## Follow-up Steps
1. Test the new functionality
2. Update any related reports or exports
3. Train users on new fields
4. Consider data migration for existing records
