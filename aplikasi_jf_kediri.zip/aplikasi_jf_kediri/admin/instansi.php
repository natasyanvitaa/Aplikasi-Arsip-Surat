<?php
require_once '../includes/header.php';

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if (isset($_POST['action'])) {
            $action = $_POST['action'];
            
            if ($action == 'add') {
                $kode_instansi = sanitize_input($_POST['kode_instansi']);
                $nama_instansi = sanitize_input($_POST['nama_instansi']);
                $alamat = sanitize_input($_POST['alamat']);
                $telepon = sanitize_input($_POST['telepon']);
                $email = sanitize_input($_POST['email']);
                
                if (empty($kode_instansi) || empty($nama_instansi)) {
                    throw new Exception("Kode Surat dan Nama OPD harus diisi!");
                }
                
                // Check for duplicate code
                $check_stmt = $conn->prepare("SELECT id_instansi FROM instansi WHERE kode_instansi = ?");
                $check_stmt->bind_param("s", $kode_instansi);
                $check_stmt->execute();
                if ($check_stmt->get_result()->num_rows > 0) {
                    throw new Exception("Kode Surat sudah ada!");
                }
                $check_stmt->close();
                
                $stmt = $conn->prepare("INSERT INTO instansi (kode_instansi, nama_instansi, alamat, telepon, email, created_at, updated_at) VALUES (?, ?, ?, ?, ?, NOW(), NOW())");
                $stmt->bind_param("sssss", $kode_instansi, $nama_instansi, $alamat, $telepon, $email);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data OPD berhasil ditambahkan!";
                } else {
                    throw new Exception("Gagal menambahkan data: " . $stmt->error);
                }
                $stmt->close();
                
            } elseif ($action == 'edit') {
                $id = intval($_POST['id']);
                $kode_instansi = sanitize_input($_POST['kode_instansi']);
                $nama_instansi = sanitize_input($_POST['nama_instansi']);
                $alamat = sanitize_input($_POST['alamat']);
                $telepon = sanitize_input($_POST['telepon']);
                $email = sanitize_input($_POST['email']);
                
                if (empty($kode_instansi) || empty($nama_instansi)) {
                    throw new Exception("Kode OPD dan Nama OPD harus diisi!");
                }
                
                // Check for duplicate code (exclude current record)
                $check_stmt = $conn->prepare("SELECT id_instansi FROM instansi WHERE kode_instansi = ? AND id_instansi != ?");
                $check_stmt->bind_param("si", $kode_instansi, $id);
                $check_stmt->execute();
                if ($check_stmt->get_result()->num_rows > 0) {
                    throw new Exception("Kode OPD sudah ada!");
                }
                $check_stmt->close();
                
                $stmt = $conn->prepare("UPDATE instansi SET kode_instansi = ?, nama_instansi = ?, alamat = ?, telepon = ?, email = ?, updated_at = NOW() WHERE id_instansi = ?");
                $stmt->bind_param("sssssi", $kode_instansi, $nama_instansi, $alamat, $telepon, $email, $id);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data OPD berhasil diperbarui!";
                } else {
                    throw new Exception("Gagal memperbarui data: " . $stmt->error);
                }
                $stmt->close();
                
            } elseif ($action == 'delete') {
                $id = intval($_POST['id']);
                
                // Check if instansi is still being used
                $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM pegawai WHERE id_instansi = ?");
                $check_stmt->bind_param("i", $id);
                $check_stmt->execute();
                $result = $check_stmt->get_result();
                $count = $result->fetch_assoc()['count'];
                $check_stmt->close();
                
                if ($count > 0) {
                    throw new Exception("OPD tidak dapat dihapus karena masih digunakan dalam data pegawai!");
                }
                
                // Check if instansi is used in rekap_jf
                $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM rekap_jf WHERE id_instansi = ?");
                $check_stmt->bind_param("i", $id);
                $check_stmt->execute();
                $result = $check_stmt->get_result();
                $count = $result->fetch_assoc()['count'];
                $check_stmt->close();
                
                if ($count > 0) {
                    throw new Exception("OPD tidak dapat dihapus karena masih digunakan dalam rekap JF!");
                }
                
                $stmt = $conn->prepare("DELETE FROM instansi WHERE id_instansi = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data OPD berhasil dihapus!";
                } else {
                    throw new Exception("Gagal menghapus data: " . $stmt->error);
                }
                $stmt->close();
            }
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
    }
    
    header("Location: instansi.php");
    exit();
}

// Get data for edit
$data_to_edit = null;
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $edit_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM instansi WHERE id_instansi = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data_to_edit = $result->fetch_assoc();
    $stmt->close();
}

// Get main data with search
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$where_clause = "";
$params = [];
$types = "";

if ($search) {
    $where_clause = "WHERE (nama_instansi LIKE ? OR kode_instansi LIKE ? OR alamat LIKE ?)";
    $search_param = "%" . $search . "%";
    $params = [$search_param, $search_param, $search_param];
    $types = "sss";
}

$sql = "SELECT * FROM instansi $where_clause ORDER BY nama_instansi ASC";

if (!empty($params)) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

// Get statistics
$stats_query = "SELECT COUNT(*) as total FROM instansi";
$stats_result = $conn->query($stats_query);
$total_instansi = $stats_result->fetch_assoc()['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen OPD - Sistem JF Kota Kediri</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: 20px;
        }

        .container {
            max-width: 1200px;
        }

        .card {
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            border: none;
            border-radius: 15px;
            margin-bottom: 30px;
        }

        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            border: none;
            padding: 20px;
        }

        .btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }

        .btn-success {
            background: linear-gradient(135deg, #81FBB8 0%, #28C76F 100%);
            border: none;
        }

        .btn-warning {
            background: linear-gradient(135deg, #FFD93D 0%, #FF6B6B 100%);
            border: none;
        }

        .btn-danger {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5253 100%);
            border: none;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
        }

        .table th {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-weight: 700;
            border: none;
            color: #495057;
            padding: 15px 12px;
        }

        .table td {
            padding: 15px 12px;
            vertical-align: middle;
            border-color: #f1f3f4;
        }

        .form-control {
            border-radius: 8px;
            border: 2px solid #e0e6ed;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        .alert {
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }

        .stats-card h4 {
            color: #667eea;
            font-weight: 700;
        }

        .stats-card p {
            font-size: 2.5em;
            font-weight: 800;
            color: #333;
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mb-4 text-center" style="color: #495057;">Manajemen OPD</h2>

        <?php 
        if (isset($_SESSION['success_message'])) {
            echo "<div class='alert alert-success'>" . $_SESSION['success_message'] . "</div>";
            unset($_SESSION['success_message']);
        }
        if (isset($_SESSION['error_message'])) {
            echo "<div class='alert alert-danger'>" . $_SESSION['error_message'] . "</div>";
            unset($_SESSION['error_message']);
        }
        ?>

        <div class="row mb-4">
            <div class="col-md-12">
                <div class="stats-card">
                    <h4>Total OPD</h4>
                    <p><?php echo $total_instansi; ?></p>
                </div>
            </div>
        </div>

        <!-- Pie Chart Container -->
        <div class="row mb-4">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Distribusi JF OPD</h5>
                    </div>
                    <div class="card-body">
                        <div id="pieChartContainer" style="position: relative; height:40vh; width:80vw; max-width: 600px; margin: 0 auto;">
                            <canvas id="instansiPieChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><?php echo $data_to_edit ? 'Edit Data OPD' : 'Tambah OPD Baru'; ?></span>
                <?php if ($data_to_edit): ?>
                    <a href="instansi.php" class="btn btn-sm btn-info">Batal Edit</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <form action="instansi.php" method="POST">
                    <input type="hidden" name="action" value="<?php echo $data_to_edit ? 'edit' : 'add'; ?>">
                    <?php if ($data_to_edit): ?>
                        <input type="hidden" name="id" value="<?php echo $data_to_edit['id_instansi']; ?>">
                    <?php endif; ?>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="kode_instansi">Kode Surat <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="kode_instansi" name="kode_instansi" value="<?php echo $data_to_edit ? htmlspecialchars($data_to_edit['kode_instansi']) : ''; ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="nama_instansi">Nama OPD <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nama_instansi" name="nama_instansi" value="<?php echo $data_to_edit ? htmlspecialchars($data_to_edit['nama_instansi']) : ''; ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <textarea class="form-control" id="alamat" name="alamat" rows="3"><?php echo $data_to_edit ? htmlspecialchars($data_to_edit['alamat']) : ''; ?></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="telepon">Telepon</label>
                            <input type="text" class="form-control" id="telepon" name="telepon" value="<?php echo $data_to_edit ? htmlspecialchars($data_to_edit['telepon']) : ''; ?>">
                        </div>
                        <div class="form-group col-md-6">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo $data_to_edit ? htmlspecialchars($data_to_edit['email']) : ''; ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-save"></i> <?php echo $data_to_edit ? 'Update Data' : 'Tambah Data'; ?>
                    </button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                Daftar OPD
            </div>
            <div class="card-body">
                <form action="instansi.php" method="GET" class="form-inline mb-3">
                    <div class="form-group mr-2">
                        <label for="search" class="sr-only">Cari</label>
                        <input type="text" class="form-control" id="search" name="search" placeholder="Cari instansi..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Cari</button>
                    <a href="instansi.php" class="btn btn-secondary ml-2"><i class="fas fa-sync-alt"></i> Reset</a>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Kode Surat</th>
                                <th>Nama Instansi</th>
                                <th>Alamat</th>
                                <th>Telepon</th>
                                <th>Email</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result && $result->num_rows > 0): ?>
                                <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo htmlspecialchars($row['kode_instansi']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_instansi']); ?></td>
                                        <td><?php echo htmlspecialchars($row['alamat']); ?></td>
                                        <td><?php echo htmlspecialchars($row['telepon']); ?></td>
                                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                                        <td>
                                            <a href="instansi.php?action=edit&id=<?php echo $row['id_instansi']; ?>" class="btn btn-sm btn-warning mb-1" title="Edit"><i class="fas fa-edit"></i></a>
                                            <button type="button" class="btn btn-sm btn-danger mb-1" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo $row['id_instansi']; ?>" title="Hapus"><i class="fas fa-trash"></i></button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center">Tidak ada data OPD.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Apakah Anda yakin ingin menghapus data ini?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <form id="deleteForm" method="POST" action="instansi.php">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" id="delete_id">
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $('#deleteModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget);
            var id = button.data('id');
            var modal = $(this);
            modal.find('#delete_id').val(id);
        });

        // Initialize pie chart
        document.addEventListener('DOMContentLoaded', function() {
            // For now, we'll create a simple pie chart with dummy data
            // In a real implementation, this would come from the database
            const ctx = document.getElementById('instansiPieChart').getContext('2d');
            const instansiPieChart = new Chart(ctx, {
                type: 'pie',
                data: {
                    labels: ['Dinas Pendidikan', 'Dinas Kesehatan', 'Dinas PU', 'Dinas Sosial'],
                    datasets: [{
                        label: 'Jumlah Instansi',
                        data: [15, 12, 8, 5],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.8)',
                            'rgba(54, 162, 235, 0.8)',
                            'rgba(255, 205, 86, 0.8)',
                            'rgba(75, 192, 192, 0.8)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 205, 86, 1)',
                            'rgba(75, 192, 192, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.label + ': ' + context.parsed;
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>
