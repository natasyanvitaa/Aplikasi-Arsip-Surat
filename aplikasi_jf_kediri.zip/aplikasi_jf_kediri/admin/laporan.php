<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include necessary files
require_once '../includes/header.php';

// Check if database connection exists
if (!isset($conn)) {
    require_once '../config/database.php';
}

// Initialize variables with default values
$filter_instansi = isset($_GET['filter_instansi']) ? $_GET['filter_instansi'] : '';
$filter_jenjang = isset($_GET['filter_jenjang']) ? $_GET['filter_jenjang'] : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Initialize empty arrays and default values
$result_report = null;
$stats = ['total_rekap' => 0, 'total_pegawai' => 0, 'total_instansi' => 0, 'total_jf' => 0];
$jenjang_chart_data = [];
$instansi_chart_data = [];
$validation_stats = ['sudah_validasi' => 0, 'belum_validasi' => 0];

try {
    // Build WHERE conditions for filters
    $where_conditions = ["r.status_validasi = 'Sudah Validasi'"];
    $params = [];
    $types = "";

    if ($filter_instansi) {
        $where_conditions[] = "r.id_instansi = ?";
        $params[] = $filter_instansi;
        $types .= "i";
    }

    if ($filter_jenjang) {
        $where_conditions[] = "r.id_jenjang = ?";
        $params[] = $filter_jenjang;
        $types .= "i";
    }

    if ($date_from) {
        $where_conditions[] = "DATE(r.tanggal_validasi) >= ?";
        $params[] = $date_from;
        $types .= "s";
    }

    if ($date_to) {
        $where_conditions[] = "DATE(r.tanggal_validasi) <= ?";
        $params[] = $date_to;
        $types .= "s";
    }

    $where_clause = "WHERE " . implode(" AND ", $where_conditions);

    // Main report query
    $sql_report = "SELECT r.*, i.nama_instansi, jf.nama_jf, jj.nama_jenjang
                   FROM rekap_jf r
                   JOIN instansi i ON r.id_instansi = i.id_instansi
                   JOIN jabatan_fungsional jf ON r.id_jf = jf.id_jf
                   JOIN jenjang_jf jj ON r.id_jenjang = jj.id_jenjang
                   $where_clause
                   ORDER BY i.nama_instansi, jf.nama_jf, jj.nama_jenjang ASC";

    if (!empty($params)) {
        $stmt = $conn->prepare($sql_report);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();
        $result_report = $stmt->get_result();
    } else {
        $result_report = $conn->query($sql_report);
    }

    // Get statistics
    $stats_query = "SELECT 
        COUNT(*) as total_rekap,
        SUM(jumlah_pegawai) as total_pegawai,
        COUNT(DISTINCT id_instansi) as total_instansi,
        COUNT(DISTINCT id_jf) as total_jf
        FROM rekap_jf r
        $where_clause";

    if (!empty($params)) {
        $stmt_stats = $conn->prepare($stats_query);
        $stmt_stats->bind_param($types, ...$params);
        $stmt_stats->execute();
        $stats_result = $stmt_stats->get_result();
    } else {
        $stats_result = $conn->query($stats_query);
    }
    
    if ($stats_result) {
        $stats = $stats_result->fetch_assoc();
    }

    // Get jenjang distribution for pie chart
    $jenjang_chart_query = "SELECT jj.nama_jenjang, SUM(r.jumlah_pegawai) AS total_per_jenjang, 
                            GROUP_CONCAT(DISTINCT i.nama_instansi ORDER BY i.nama_instansi SEPARATOR ', ') as nama_opd
                            FROM rekap_jf r
                            JOIN jenjang_jf jj ON r.id_jenjang = jj.id_jenjang
                            JOIN instansi i ON r.id_instansi = i.id_instansi
                            $where_clause
                            GROUP BY jj.id_jenjang, jj.nama_jenjang
                            ORDER BY total_per_jenjang DESC";

    if (!empty($params)) {
        $stmt_jenjang = $conn->prepare($jenjang_chart_query);
        $stmt_jenjang->bind_param($types, ...$params);
        $stmt_jenjang->execute();
        $jenjang_chart_result = $stmt_jenjang->get_result();
    } else {
        $jenjang_chart_result = $conn->query($jenjang_chart_query);
    }

    if ($jenjang_chart_result) {
        while ($row = $jenjang_chart_result->fetch_assoc()) {
            $jenjang_chart_data[] = $row;
        }
    }

    // Get instansi distribution for bar chart
    $instansi_chart_query = "SELECT i.nama_instansi, SUM(r.jumlah_pegawai) AS total_per_instansi
                             FROM rekap_jf r
                             JOIN instansi i ON r.id_instansi = i.id_instansi
                             $where_clause
                             GROUP BY i.id_instansi, i.nama_instansi
                             ORDER BY total_per_instansi DESC
                             LIMIT 10";

    if (!empty($params)) {
        $stmt_instansi = $conn->prepare($instansi_chart_query);
        $stmt_instansi->bind_param($types, ...$params);
        $stmt_instansi->execute();
        $instansi_chart_result = $stmt_instansi->get_result();
    } else {
        $instansi_chart_result = $conn->query($instansi_chart_query);
    }

    if ($instansi_chart_result) {
        while ($row = $instansi_chart_result->fetch_assoc()) {
            $instansi_chart_data[] = $row;
        }
    }

    // Get validation status distribution
    $validation_stats_query = "SELECT 
        SUM(CASE WHEN status_validasi = 'Sudah Validasi' THEN 1 ELSE 0 END) as sudah_validasi,
        SUM(CASE WHEN status_validasi = 'Belum Validasi' THEN 1 ELSE 0 END) as belum_validasi
        FROM rekap_jf";
    $validation_stats_result = $conn->query($validation_stats_query);
    
    if ($validation_stats_result) {
        $validation_stats = $validation_stats_result->fetch_assoc();
    }

} catch (Exception $e) {
    // Handle database errors gracefully
    $error_message = "Database Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Rekap JF - Sistem JF Kota Kediri</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: 20px;
        }

        .container {
            max-width: 1200px;
        }

        .card {
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            border: none;
            border-radius: 15px;
            margin-bottom: 30px;
        }

        .card-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            border: none;
            padding: 20px;
        }

        .btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }

        .btn-success {
            background: linear-gradient(135deg, #81FBB8 0%, #28C76F 100%);
            border: none;
        }

        .btn-info {
            background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            border: none;
        }

        .btn-warning {
            background: linear-gradient(135deg, #FFD93D 0%, #FF6B6B 100%);
            border: none;
        }

        .btn-secondary {
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
            border: none;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
        }

        .table th {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-weight: 700;
            border: none;
            color: #495057;
            padding: 15px 12px;
        }

        .table td {
            padding: 15px 12px;
            vertical-align: middle;
            border-color: #f1f3f4;
        }

        .form-control {
            border-radius: 8px;
            border: 2px solid #e0e6ed;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        .badge-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 8px 15px;
            border-radius: 25px;
            font-size: 11px;
            font-weight: 600;
        }

        .alert {
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .stats-card h4 {
            color: #667eea;
            font-weight: 700;
        }
        .stats-card p {
            font-size: 2.5em;
            font-weight: 800;
            color: #333;
            margin: 0;
        }

        @media print {
            body {
                background: white !important;
            }
            .no-print {
                display: none !important;
            }
            .card {
                box-shadow: none !important;
                border: 1px solid #ddd !important;
            }
            .card-header {
                background: #f8f9fa !important;
                color: #333 !important;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 style="color: #495057;">Laporan Rekapitulasi Jabatan Fungsional</h2>
            <button onclick="window.print()" class="btn btn-info no-print">
                <i class="fas fa-print"></i> Cetak Laporan
            </button>
        </div>

        <!-- Statistics Cards -->
        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>Total Rekap</h4>
                    <p><?php echo $stats['total_rekap']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>Total Pegawai</h4>
                    <p><?php echo $stats['total_pegawai']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>Total Instansi</h4>
                    <p><?php echo $stats['total_instansi']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>Total JF</h4>
                    <p><?php echo $stats['total_jf']; ?></p>
                </div>
            </div>
        </div>

        <!-- Filter Section -->
        <div class="card mb-4 no-print">
            <div class="card-header">
                <h5 class="mb-0">Filter Laporan</h5>
            </div>
            <div class="card-body">
                <form action="laporan.php" method="GET" class="form-inline">
                    <div class="form-group mr-2 mb-2">
                        <label for="filter_instansi" class="sr-only">Filter Instansi</label>
                        <select class="form-control" id="filter_instansi" name="filter_instansi">
                            <option value="">Semua Instansi</option>
                            <?php
                            $instansi_filter_result = $conn->query("SELECT * FROM instansi ORDER BY nama_instansi ASC");
                            while ($row = $instansi_filter_result->fetch_assoc()) {
                                $selected = ($filter_instansi == $row['id_instansi']) ? 'selected' : '';
                                echo "<option value='" . $row['id_instansi'] . "' " . $selected . ">" . htmlspecialchars($row['nama_instansi']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group mr-2 mb-2">
                        <label for="filter_jenjang" class="sr-only">Filter Jenjang</label>
                        <select class="form-control" id="filter_jenjang" name="filter_jenjang">
                            <option value="">Semua Jenjang</option>
                            <?php
                            $jenjang_filter_result = $conn->query("SELECT * FROM jenjang_jf ORDER BY nama_jenjang ASC");
                            while ($row = $jenjang_filter_result->fetch_assoc()) {
                                $selected = ($filter_jenjang == $row['id_jenjang']) ? 'selected' : '';
                                echo "<option value='" . $row['id_jenjang'] . "' " . $selected . ">" . htmlspecialchars($row['nama_jenjang']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group mr-2 mb-2">
                        <label for="date_from" class="sr-only">Tanggal Dari</label>
                        <input type="date" class="form-control" id="date_from" name="date_from" value="<?php echo htmlspecialchars($date_from); ?>" placeholder="Tanggal Dari">
                    </div>
                    <div class="form-group mr-2 mb-2">
                        <label for="date_to" class="sr-only">Tanggal Sampai</label>
                        <input type="date" class="form-control" id="date_to" name="date_to" value="<?php echo htmlspecialchars($date_to); ?>" placeholder="Tanggal Sampai">
                    </div>
                    <button type="submit" class="btn btn-primary mb-2"><i class="fas fa-filter"></i> Filter</button>
                    <a href="laporan.php" class="btn btn-secondary ml-2 mb-2"><i class="fas fa-sync-alt"></i> Reset</a>
                </form>
            </div>
        </div>

        <!-- Charts Section -->
        <div class="row mb-4 no-print">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">Visualisasi Data Laporan</h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <h6 class="text-center">Distribusi per Jenjang</h6>
                                <div style="position: relative; height:25vh; width:100%;">
                                    <canvas id="jenjangPieChart"></canvas>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <h6 class="text-center">Status Validasi (Keseluruhan)</h6>
                                <div style="position: relative; height:25vh; width:100%;">
                                    <canvas id="validasiPieChart"></canvas>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <h6 class="text-center">Top 10 Instansi</h6>
                                <div style="position: relative; height:25vh; width:100%;">
                                    <canvas id="instansiBarChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Report Table -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Data Rekap JF yang Sudah Divalidasi</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-striped table-bordered">
                        <thead style="background-color: #f8f9fa !important; color: #000 !important;">
                            <tr>
                                <th width="5%" class="text-center">#</th>
                                <th width="20%">Instansi</th>
                                <th width="20%">Jabatan Fungsional</th>
                                <th width="15%" class="text-center">Jenjang</th>
                                <th width="12%" class="text-center">Jumlah Pegawai</th>
                                <th width="13%" class="text-center">Status Validasi</th>
                                <th width="15%" class="text-center">Tanggal Validasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result_report->num_rows > 0): ?>
                                <?php 
                                $no = 1; 
                                $total_pegawai = 0; 
                                while ($row_report = $result_report->fetch_assoc()): 
                                    $total_pegawai += $row_report['jumlah_pegawai']; 
                                ?>
                                    <tr>
                                        <td class="text-center align-middle"><?php echo $no++; ?></td>
                                        <td class="align-middle"><?php echo htmlspecialchars($row_report['nama_instansi']); ?></td>
                                        <td class="align-middle"><?php echo htmlspecialchars($row_report['nama_jf']); ?></td>
                                        <td class="text-center align-middle">
                                            <span class="badge badge-primary">
                                                <?php echo htmlspecialchars($row_report['nama_jenjang']); ?>
                                            </span>
                                        </td>
                                        <td class="text-center align-middle">
                                            <strong><?php echo number_format($row_report['jumlah_pegawai']); ?></strong>
                                        </td>
                                        <td class="text-center align-middle">
                                            <span class="badge badge-success">
                                                <?php echo htmlspecialchars($row_report['status_validasi']); ?>
                                            </span>
                                        </td>
                                        <td class="text-center align-middle">
                                            <?php 
                                            if ($row_report['tanggal_validasi']) {
                                                echo date('d/m/Y', strtotime($row_report['tanggal_validasi']));
                                            } else {
                                                echo '<span class="badge badge-secondary">N/A</span>';
                                            }
                                            ?>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                                <tr class="table-secondary font-weight-bold">
                                    <td colspan="4" class="text-right align-middle"><strong>Total Keseluruhan:</strong></td>
                                    <td class="text-center align-middle">
                                        <h5><span class="badge badge-info"><?php echo number_format($total_pegawai); ?></span></h5>
                                    </td>
                                    <td colspan="2" class="align-middle">
                                        <small class="text-muted">Data dari <?php echo $result_report->num_rows; ?> entri</small>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center py-4">
                                        <i class="fas fa-info-circle fa-2x text-muted mb-2"></i><br>
                                        <strong>Tidak ada data laporan yang sudah divalidasi.</strong><br>
                                        <small class="text-muted">Silakan ubah filter atau tambahkan data rekap JF yang sudah divalidasi.</small>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Summary by Jenjang -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Ringkasan Distribusi JF Berdasarkan Jenjang</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover table-striped table-bordered">
                        <thead style="background-color: #f8f9fa !important; color: #000 !important;">
                            <tr>
                                <th width="5%" class="text-center">#</th>
                                <th width="25%">Jenjang JF</th>
                                <th width="35%">OPD</th>
                                <th width="15%" class="text-center">Total Pegawai</th>
                                <th width="15%" class="text-center">Persentase</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($jenjang_chart_data)): ?>
                                <?php 
                                $no = 1; 
                                $grand_total = array_sum(array_column($jenjang_chart_data, 'total_per_jenjang'));
                                foreach ($jenjang_chart_data as $data): 
                                    $percentage = $grand_total > 0 ? round(($data['total_per_jenjang'] / $grand_total) * 100, 2) : 0;
                                ?>
                                    <tr>
                                        <td class="text-center align-middle"><?php echo $no++; ?></td>
                                        <td class="align-middle">
                                            <span class="badge badge-primary"><?php echo htmlspecialchars($data['nama_jenjang']); ?></span>
                                        </td>
                                        <td class="align-middle">
                                            <small><?php echo htmlspecialchars($data['nama_opd'] ? $data['nama_opd'] : '-'); ?></small>
                                        </td>
                                        <td class="text-center align-middle">
                                            <strong><?php echo number_format($data['total_per_jenjang']); ?></strong>
                                        </td>
                                        <td class="text-center align-middle">
                                            <span class="badge badge-secondary"><?php echo $percentage; ?>%</span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                <tr class="table-secondary font-weight-bold">
                                    <td colspan="3" class="text-right align-middle"><strong>Total Keseluruhan:</strong></td>
                                    <td class="text-center align-middle">
                                        <h5><span class="badge badge-info"><?php echo number_format($grand_total); ?></span></h5>
                                    </td>
                                    <td class="text-center align-middle">
                                        <strong>100%</strong>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center py-4">
                                        <i class="fas fa-info-circle fa-2x text-muted mb-2"></i><br>
                                        <strong>Tidak ada data ringkasan jenjang JF.</strong><br>
                                        <small class="text-muted">Silakan ubah filter atau tambahkan data rekap JF yang sudah divalidasi.</small>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Initialize charts
        document.addEventListener('DOMContentLoaded', function() {
            // Jenjang Pie Chart
            const jenjangCtx = document.getElementById('jenjangPieChart').getContext('2d');
            const jenjangPieChart = new Chart(jenjangCtx, {
                type: 'pie',
                data: {
                    labels: [
                        <?php 
                        foreach ($jenjang_chart_data as $data) {
                            echo "'" . addslashes($data['nama_jenjang']) . "',";
                        }
                        ?>
                    ],
                    datasets: [{
                        label: 'Jumlah Pegawai',
                        data: [
                            <?php 
                            foreach ($jenjang_chart_data as $data) {
                                echo $data['total_per_jenjang'] . ",";
                            }
                            ?>
                        ],
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.8)',
                            'rgba(54, 162, 235, 0.8)',
                            'rgba(255, 205, 86, 0.8)',
                            'rgba(75, 192, 192, 0.8)',
                            'rgba(153, 102, 255, 0.8)',
                            'rgba(255, 159, 64, 0.8)'
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 205, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.label + ': ' + context.parsed;
                                }
                            }
                        }
                    }
                }
            });

            // Validation Status Pie Chart
            const validasiCtx = document.getElementById('validasiPieChart').getContext('2d');
            const validasiPieChart = new Chart(validasiCtx, {
                type: 'pie',
                data: {
                    labels: ['Sudah Validasi', 'Belum Validasi'],
                    datasets: [{
                        label: 'Jumlah Rekap',
                        data: [<?php echo $validation_stats['sudah_validasi']; ?>, <?php echo $validation_stats['belum_validasi']; ?>],
                        backgroundColor: [
                            'rgba(75, 192, 192, 0.8)',
                            'rgba(255, 205, 86, 0.8)'
                        ],
                        borderColor: [
                            'rgba(75, 192, 192, 1)',
                            'rgba(255, 205, 86, 1)'
                        ],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.label + ': ' + context.parsed;
                                }
                            }
                        }
                    }
                }
            });

            // Instansi Bar Chart
            const instansiCtx = document.getElementById('instansiBarChart').getContext('2d');
            const instansiBarChart = new Chart(instansiCtx, {
                type: 'bar',
                data: {
                    labels: [
                        <?php 
                        foreach ($instansi_chart_data as $data) {
                            echo "'" . addslashes(substr($data['nama_instansi'], 0, 15)) . "...',";
                        }
                        ?>
                    ],
                    datasets: [{
                        label: 'Jumlah Pegawai',
                        data: [
                            <?php 
                            foreach ($instansi_chart_data as $data) {
                                echo $data['total_per_instansi'] . ",";
                            }
                            ?>
                        ],
                        backgroundColor: 'rgba(54, 162, 235, 0.8)',
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: false
                        },
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return 'Jumlah Pegawai: ' + context.parsed.y;
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>

<?php require_once '../includes/footer.php'; ?>
