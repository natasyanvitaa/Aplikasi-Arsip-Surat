<?php
require_once '../db.php';
require_once '../functions.php';

if (!isset($_GET['type']) || !isset($_GET['table'])) {
    die('Parameter tidak lengkap');
}

$type = $_GET['type'];
$table = $_GET['table'];

// Generate filename with timestamp
$timestamp = date('Y-m-d_H-i-s');
$filename = "export_{$table}_{$timestamp}";

if ($table == 'jf_opd' && $type == 'excel') {
    // Export JF-OPD data to Excel
    $sql = "SELECT 
                i.nama_instansi as 'Instansi/OPD',
                jf.nama_jf as 'Jabatan Fungsional',
                jf.kategori as 'Kategori JF',
                jj.nama_jenjang as 'Jenjang',
                t.jumlah_pegawai as 'Jumlah Pegawai',
                CASE t.status_tracking
                    WHEN 0 THEN 'Belum Dihitung'
                    WHEN 1 THEN 'Sedang Dihitung'
                    WHEN 2 THEN 'Diminta Rekomendasi'
                    WHEN 3 THEN 'Telah Diminta Rekomendasi'
                    WHEN 4 THEN 'Diminta Validasi Menpan'
                    WHEN 5 THEN 'Sudah Divalidasi Menpan'
                    WHEN 6 THEN 'Dibuatkan Dasar Hukum'
                    ELSE 'Status Tidak Dikenal'
                END as 'Status',
                t.tanggal_mulai as 'Tanggal Mulai',
                t.tanggal_selesai as 'Tanggal Selesai',
                t.catatan as 'Catatan',
                t.dasar_hukum as 'Dasar Hukum',
                t.created_at as 'Tanggal Input',
                t.updated_at as 'Tanggal Update'
            FROM jf_opd_tracking t
            JOIN instansi i ON t.id_instansi = i.id_instansi
            JOIN jabatan_fungsional jf ON t.id_jf = jf.id_jf
            LEFT JOIN jenjang_jf jj ON t.id_jenjang = jj.id_jenjang
            ORDER BY i.nama_instansi, jf.nama_jf";
    
    $result = $conn->query($sql);
    $data = [];
    $headers = [];
    
    if ($result->num_rows > 0) {
        // Get headers from first row
        $first_row = $result->fetch_assoc();
        $headers = array_keys($first_row);
        $data[] = array_values($first_row);
        
        // Get remaining data
        while ($row = $result->fetch_assoc()) {
            $data[] = array_values($row);
        }
    }
    
    export_to_excel($data, $filename, $headers);
    
} elseif ($table == 'jf_opd' && $type == 'pdf') {
    // Export JF-OPD data to PDF (using HTML to PDF conversion)
    $sql = "SELECT 
                i.nama_instansi,
                jf.nama_jf,
                jf.kategori,
                jj.nama_jenjang,
                t.jumlah_pegawai,
                t.status_tracking,
                t.tanggal_mulai,
                t.tanggal_selesai,
                t.created_at
            FROM jf_opd_tracking t
            JOIN instansi i ON t.id_instansi = i.id_instansi
            JOIN jabatan_fungsional jf ON t.id_jf = jf.id_jf
            LEFT JOIN jenjang_jf jj ON t.id_jenjang = jj.id_jenjang
            ORDER BY i.nama_instansi, jf.nama_jf";
    
    $result = $conn->query($sql);
    
    // Set headers for PDF
    header('Content-Type: text/html; charset=utf-8');
    
    echo '<!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Laporan JF-OPD</title>
        <style>
            body { font-family: Arial, sans-serif; font-size: 12px; }
            .header { text-align: center; margin-bottom: 20px; }
            .header h1 { margin: 0; color: #333; }
            .header p { margin: 5px 0; color: #666; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; font-weight: bold; }
            .status-0 { background-color: #f8f9fa; }
            .status-1 { background-color: #d1ecf1; }
            .status-2 { background-color: #fff3cd; }
            .status-3 { background-color: #cce5ff; }
            .status-4 { background-color: #f8d7da; }
            .status-5 { background-color: #d4edda; }
            .status-6 { background-color: #d6d8db; }
            .footer { margin-top: 30px; text-align: center; font-size: 10px; color: #666; }
        </style>
    </head>
    <body>
        <div class="header">
            <h1>LAPORAN TRACKING JABATAN FUNGSIONAL - OPD</h1>
            <p>Sistem Informasi Jabatan Fungsional Kota Kediri</p>
            <p>Tanggal Export: ' . date('d/m/Y H:i:s') . '</p>
        </div>
        
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Instansi/OPD</th>
                    <th>Jabatan Fungsional</th>
                    <th>Kategori</th>
                    <th>Jenjang</th>
                    <th>Jumlah Pegawai</th>
                    <th>Status</th>
                    <th>Tanggal Input</th>
                </tr>
            </thead>
            <tbody>';
    
    if ($result->num_rows > 0) {
        $no = 1;
        while ($row = $result->fetch_assoc()) {
            $status_label = get_status_tracking_label($row['status_tracking']);
            $status_class = 'status-' . $row['status_tracking'];
            
            echo '<tr class="' . $status_class . '">
                    <td>' . $no++ . '</td>
                    <td>' . htmlspecialchars($row['nama_instansi']) . '</td>
                    <td>' . htmlspecialchars($row['nama_jf']) . '</td>
                    <td>' . ucfirst($row['kategori']) . '</td>
                    <td>' . htmlspecialchars($row['nama_jenjang'] ?? '-') . '</td>
                    <td>' . $row['jumlah_pegawai'] . '</td>
                    <td>' . $status_label . '</td>
                    <td>' . format_tanggal($row['created_at']) . '</td>
                  </tr>';
        }
    } else {
        echo '<tr><td colspan="8" style="text-align: center;">Tidak ada data</td></tr>';
    }
    
    echo '</tbody>
        </table>
        
        <div class="footer">
            <p>Dicetak pada: ' . date('d/m/Y H:i:s') . ' | Sistem Informasi JF Kota Kediri</p>
        </div>
        
        <script>
            window.onload = function() {
                window.print();
            }
        </script>
    </body>
    </html>';
    
} else {
    die('Tipe export tidak didukung');
}
?>
