<?php
include 'db.php';

echo "Structure for table: jabatan_fungsional\n";
$sql = "DESCRIBE jabatan_fungsional";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "  - " . $row['Field'] . " (" . $row['Type'] . ")\n";
    }
} else {
    echo "  Table not found or no columns\n";
}

$conn->close();
?>
