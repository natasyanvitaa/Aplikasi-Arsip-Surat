<?php
include 'db.php';

$tables = ['instansi', 'jenjang_jf'];

foreach ($tables as $table) {
    echo "Structure for table: $table\n";
    $sql = "DESCRIBE $table";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            echo "  - " . $row['Field'] . " (" . $row['Type'] . ")\n";
        }
    }
    echo "\n";
}

$conn->close();
?>
