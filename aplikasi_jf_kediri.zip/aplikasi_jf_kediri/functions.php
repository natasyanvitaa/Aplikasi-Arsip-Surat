<?php
// Fungsi untuk membersihkan input
function sanitize_input($data) {
    global $conn;
    if ($data === null) return null;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = mysqli_real_escape_string($conn, $data);
    return $data;
}

// Fungsi untuk redirect
function redirect($url) {
    header("Location: " . $url);
    exit();
}

// Fungsi untuk mengecek login
function is_logged_in() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

// Fungsi untuk mengecek role admin
function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// Fungsi untuk proteksi halaman
function require_login() {
    if (!is_logged_in()) {
        redirect('../index.php');
    }
}

// Fungsi untuk proteksi halaman admin
function require_admin() {
    require_login();
    if (!is_admin()) {
        redirect('../admin/index.php?error=access_denied');
    }
}

// Fungsi untuk mendapatkan nama instansi
function get_nama_instansi($id_instansi) {
    global $conn;
    if (empty($id_instansi)) return "N/A";
    $id_instansi = sanitize_input($id_instansi);
    $sql = "SELECT nama_instansi FROM instansi WHERE id_instansi = '$id_instansi'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['nama_instansi'];
    }
    return "N/A";
}

// Fungsi untuk mendapatkan nama JF
function get_nama_jf($id_jf) {
    global $conn;
    if (empty($id_jf)) return "N/A";
    $id_jf = sanitize_input($id_jf);
    $sql = "SELECT nama_jf FROM jabatan_fungsional WHERE id_jf = '$id_jf'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['nama_jf'];
    }
    return "N/A";
}

// Fungsi untuk mendapatkan nama jenjang
function get_nama_jenjang($id_jenjang) {
    global $conn;
    if (empty($id_jenjang)) return "N/A";
    $id_jenjang = sanitize_input($id_jenjang);
    $sql = "SELECT nama_jenjang FROM jenjang_jf WHERE id_jenjang = '$id_jenjang'";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['nama_jenjang'];
    }
    return "N/A";
}

// Fungsi untuk format tanggal Indonesia
function format_tanggal($tanggal) {
    if (empty($tanggal) || $tanggal == '0000-00-00 00:00:00') return '-';
    return date('d/m/Y H:i', strtotime($tanggal));
}

// Fungsi untuk generate alert
function show_alert($message, $type = 'success') {
    return "<div class='alert alert-{$type}'>{$message}</div>";
}

// Fungsi untuk pagination
function paginate($total_records, $records_per_page, $current_page, $base_url) {
    $total_pages = ceil($total_records / $records_per_page);
    $pagination = '';
    
    if ($total_pages > 1) {
        $pagination .= '<div class="pagination">';
        
        // Previous
        if ($current_page > 1) {
            $prev_page = $current_page - 1;
            $pagination .= "<a href='{$base_url}?page={$prev_page}' class='page-link'>&laquo; Prev</a>";
        }
        
        // Page numbers
        for ($i = 1; $i <= $total_pages; $i++) {
            $active = ($i == $current_page) ? 'active' : '';
            $pagination .= "<a href='{$base_url}?page={$i}' class='page-link {$active}'>{$i}</a>";
        }
        
        // Next
        if ($current_page < $total_pages) {
            $next_page = $current_page + 1;
            $pagination .= "<a href='{$base_url}?page={$next_page}' class='page-link'>Next &raquo;</a>";
        }
        
        $pagination .= '</div>';
    }
    
    return $pagination;
}

// Fungsi untuk mendapatkan status tracking JF-OPD
function get_status_tracking_label($status) {
    $status_labels = [
        0 => 'Belum Dihitung',
        1 => 'Sedang Dihitung',
        2 => 'Diminta Rekomendasi',
        3 => 'Telah Diminta Rekomendasi',
        4 => 'Diminta Validasi Menpan',
        5 => 'Sudah Divalidasi Menpan',
        6 => 'Dibuatkan Dasar Hukum'
    ];
    return isset($status_labels[$status]) ? $status_labels[$status] : 'Status Tidak Dikenal';
}

// Fungsi untuk mendapatkan warna badge status
function get_status_badge_class($status) {
    $badge_classes = [
        0 => 'badge-secondary',
        1 => 'badge-info',
        2 => 'badge-warning',
        3 => 'badge-primary',
        4 => 'badge-danger',
        5 => 'badge-success',
        6 => 'badge-dark'
    ];
    return isset($badge_classes[$status]) ? $badge_classes[$status] : 'badge-secondary';
}

// Fungsi untuk upload file
function upload_file($file, $target_dir = 'uploads/dokumen_pendukung/') {
    $upload_result = ['success' => false, 'message' => '', 'filename' => ''];
    
    // Validasi file
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        $upload_result['message'] = 'Error dalam upload file.';
        return $upload_result;
    }
    
    // Validasi tipe file
    $allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    $file_type = $file['type'];
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    if (!in_array($file_type, $allowed_types) && !in_array($file_extension, ['pdf', 'doc', 'docx'])) {
        $upload_result['message'] = 'Hanya file PDF, DOC, dan DOCX yang diizinkan.';
        return $upload_result;
    }
    
    // Validasi ukuran file (max 10MB)
    if ($file['size'] > 10 * 1024 * 1024) {
        $upload_result['message'] = 'Ukuran file maksimal 10MB.';
        return $upload_result;
    }
    
    // Generate nama file unik
    $filename = date('YmdHis') . '_' . uniqid() . '.' . $file_extension;
    $target_path = $target_dir . $filename;
    
    // Buat direktori jika belum ada
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0755, true);
    }
    
    // Upload file
    if (move_uploaded_file($file['tmp_name'], $target_path)) {
        $upload_result['success'] = true;
        $upload_result['filename'] = $filename;
        $upload_result['message'] = 'File berhasil diupload.';
    } else {
        $upload_result['message'] = 'Gagal mengupload file.';
    }
    
    return $upload_result;
}

// Fungsi untuk menghapus file
function delete_file($filename, $target_dir = 'uploads/dokumen_pendukung/') {
    $file_path = $target_dir . $filename;
    if (file_exists($file_path)) {
        return unlink($file_path);
    }
    return false;
}

// Fungsi untuk mendapatkan ukuran file yang readable
function format_file_size($bytes) {
    if ($bytes >= 1073741824) {
        return number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        return number_format($bytes / 1024, 2) . ' KB';
    } else {
        return $bytes . ' bytes';
    }
}

// Fungsi untuk generate Excel export
function export_to_excel($data, $filename, $headers = []) {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="' . $filename . '.xls"');
    header('Cache-Control: max-age=0');
    
    echo '<table border="1">';
    
    // Headers
    if (!empty($headers)) {
        echo '<tr>';
        foreach ($headers as $header) {
            echo '<th>' . htmlspecialchars($header) . '</th>';
        }
        echo '</tr>';
    }
    
    // Data
    foreach ($data as $row) {
        echo '<tr>';
        foreach ($row as $cell) {
            echo '<td>' . htmlspecialchars($cell) . '</td>';
        }
        echo '</tr>';
    }
    
    echo '</table>';
}

// Fungsi untuk mendapatkan nama pembina JF
function get_nama_pembina($id_jf) {
    global $conn;
    if (empty($id_jf)) return "N/A";
    $id_jf = sanitize_input($id_jf);
    $sql = "SELECT nama_pembina FROM pembina_jf WHERE id_jf = '$id_jf' AND status_aktif = 'aktif' LIMIT 1";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['nama_pembina'];
    }
    return "N/A";
}

// Fungsi untuk mendapatkan nama koordinator JF
function get_nama_koordinator($id_jf, $id_instansi) {
    global $conn;
    if (empty($id_jf) || empty($id_instansi)) return "N/A";
    $id_jf = sanitize_input($id_jf);
    $id_instansi = sanitize_input($id_instansi);
    $sql = "SELECT nama_koordinator FROM koordinator_jf WHERE id_jf = '$id_jf' AND id_instansi = '$id_instansi' AND status_aktif = 'aktif' LIMIT 1";
    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['nama_koordinator'];
    }
    return "N/A";
}

// Fungsi untuk log aktivitas
function log_activity($action, $description, $user_id = null) {
    global $conn;
    $user_id = $user_id ?? ($_SESSION['user_id'] ?? null);
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    
    $stmt = $conn->prepare("INSERT INTO activity_log (user_id, action, description, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    if ($stmt) {
        $stmt->bind_param("issss", $user_id, $action, $description, $ip_address, $user_agent);
        $stmt->execute();
        $stmt->close();
    }
}
?>
