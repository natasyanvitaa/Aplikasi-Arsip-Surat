-- Fix for missing pembina_jf column in jabatan_fungsional table
-- This script adds the missing pembina_jf column to resolve the error:
-- "Error preparing insert statement: Unknown column 'pembina_jf' in 'field list'"

ALTER TABLE `jabatan_fungsional` 
ADD COLUMN `pembina_jf` VARCHAR(255) DEFAULT NULL 
COMMENT 'Pembina Jabatan Fungsional' 
AFTER `nama_jf`;

-- Verify the column was added successfully
DESCRIBE jabatan_fungsional;
