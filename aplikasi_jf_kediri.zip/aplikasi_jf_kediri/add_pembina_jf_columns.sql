-- Add new columns for pembina jabatan fungsional and jabatan fungsional
ALTER TABLE jabatan_fungsional 
ADD COLUMN pembina_jabatan_fungsional VARCHAR(255) NULL COMMENT 'Instansi pembina jabatan fungsional',
ADD COLUMN jabatan_fungsional VARCHAR(255) NULL COMMENT 'Nama jabatan fungsional';

-- Create index for better performance on new columns
CREATE INDEX idx_pembina_jf ON jabatan_fungsional(pembina_jabatan_fungsional);
CREATE INDEX idx_jabatan_fungsional ON jabatan_fungsional(jabatan_fungsional);
