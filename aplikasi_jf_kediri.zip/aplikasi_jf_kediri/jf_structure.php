<?php
include 'db.php';

$sql = "DESCRIBE jabatan_fungsional";
$result = $conn->query($sql);

echo "Structure for table: jabatan_fungsional\n";
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "  - " . $row['Field'] . " (" . $row['Type'] . ")\n";
    }
}

$conn->close();
?>
