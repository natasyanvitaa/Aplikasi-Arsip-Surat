<?php
require_once 'db.php';

// Check if all required tables exist
$tables = [
    'instansi',
    'jenjang_jf',
    'jabatan_fungsional',
    'pegawai',
    'rekap_jf',
    'jf_opd_tracking',
    'dokumen_pendukung',
    'pembina_jf',
    'koordinator_jf'
];

echo "Checking database structure...\n";

foreach ($tables as $table) {
    $sql = "SHOW TABLES LIKE '$table'";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        echo "✓ Table '$table' exists\n";
    } else {
        echo "✗ Table '$table' does not exist\n";
    }
}

// Check table structures
echo "\nChecking table structures...\n";

foreach ($tables as $table) {
    $sql = "DESCRIBE $table";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        echo "Structure of table '$table':\n";
        while ($row = $result->fetch_assoc()) {
            echo "  - " . $row['Field'] . " (" . $row['Type'] . ")\n";
        }
        echo "\n";
    } else {
        echo "Could not get structure for table '$table'\n";
    }
}

$conn->close();
?>
