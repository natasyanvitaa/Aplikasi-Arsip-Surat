<?php
// Test database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_jf_kediri";

echo "Attempting to connect to database...\n";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully\n";

// Test a simple query
$sql = "SELECT 1";
$result = $conn->query($sql);

if ($result) {
    echo "Database query successful\n";
} else {
    echo "Database query failed: " . $conn->error . "\n";
}

$conn->close();
echo "Connection closed\n";
?>
