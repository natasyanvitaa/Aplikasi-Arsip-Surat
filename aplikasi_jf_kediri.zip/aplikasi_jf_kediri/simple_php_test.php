<?php
// Simple PHP test
file_put_contents('php_test_output.txt', "PHP is working correctly\n");
echo "PHP test completed successfully\n";
?>
