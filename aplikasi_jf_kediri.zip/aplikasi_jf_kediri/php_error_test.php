<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Simple test
echo "PHP is working\n";

// Database connection test
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_jf_kediri";

echo "Attempting database connection...\n";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo "Connection failed: " . $conn->connect_error . "\n";
} else {
    echo "Connected successfully\n";
    
    // Get tables
    $sql = "SHOW TABLES";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo "Tables in database:\n";
        while($row = $result->fetch_array()) {
            echo "- " . $row[0] . "\n";
        }
    } else {
        echo "No tables found\n";
    }
}

$conn->close();
echo "Test completed\n";
?>
