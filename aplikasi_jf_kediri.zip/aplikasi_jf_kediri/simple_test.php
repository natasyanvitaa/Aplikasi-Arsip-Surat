<?php
echo "PHP is working correctly\n";
?>
