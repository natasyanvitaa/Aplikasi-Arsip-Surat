<?php
// Simple database connection test
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_jf_kediri";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully\n";

// Check if instansi table exists
$sql = "SHOW TABLES LIKE 'instansi'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    echo "Table 'instansi' exists\n";
} else {
    echo "Table 'instansi' does not exist\n";
}

// Try to insert a test record
$sql = "INSERT INTO instansi (kode_instansi, nama_instansi) VALUES ('TEST001', 'Test Instansi')";
if ($conn->query($sql) === TRUE) {
    echo "Test record inserted successfully\n";
    // Delete the test record
    $last_id = $conn->insert_id;
    $sql = "DELETE FROM instansi WHERE id_instansi = $last_id";
    if ($conn->query($sql) === TRUE) {
        echo "Test record deleted successfully\n";
    }
} else {
    echo "Error inserting test record: " . $conn->error . "\n";
}

$conn->close();
echo "Test completed\n";
?>
