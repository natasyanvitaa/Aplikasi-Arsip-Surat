-- Create missing tables for the JF-OPD Management System

-- Create instansi table
CREATE TABLE IF NOT EXISTS `instansi` (
  `id_instansi` int(11) NOT NULL AUTO_INCREMENT,
  `kode_instansi` varchar(50) NOT NULL,
  `nama_instansi` varchar(255) NOT NULL,
  `alamat` text,
  `telepon` varchar(50),
  `email` varchar(100),
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_instansi`),
  UNIQUE KEY `kode_instansi` (`kode_instansi`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create jenjang_jf table
CREATE TABLE IF NOT EXISTS `jenjang_jf` (
  `id_jenjang` int(11) NOT NULL AUTO_INCREMENT,
  `kode_jenjang` varchar(50) NOT NULL,
  `nama_jenjang` varchar(255) NOT NULL,
  `kategori` enum('keahlian','keterampilan') NOT NULL,
  `angka_kredit_minimal` decimal(10,2) NOT NULL,
  `pengalaman_kerja_tahun` int(11) NOT NULL,
  `urutan` int(11) NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_jenjang`),
  UNIQUE KEY `kode_jenjang` (`kode_jenjang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create jabatan_fungsional table
CREATE TABLE IF NOT EXISTS `jabatan_fungsional` (
  `id_jf` int(11) NOT NULL AUTO_INCREMENT,
  `kode_jf` varchar(50) NOT NULL,
  `nama_jf` varchar(255) NOT NULL,
  `kategori` enum('keahlian','keterampilan') NOT NULL,
  `pendidikan_minimal` varchar(100) NOT NULL,
  `organisasi_profesi` varchar(255),
  `angka_kredit_minimal` decimal(10,2) NOT NULL,
  `tugas_pokok` text,
  `fungsi` text,
  `deskripsi` text,
  `status_aktif` enum('aktif','nonaktif') DEFAULT 'aktif',
  `status_validasi` varchar(255) NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_jf`),
  UNIQUE KEY `kode_jf` (`kode_jf`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create pegawai table
CREATE TABLE IF NOT EXISTS `pegawai` (
  `id_pegawai` int(11) NOT NULL AUTO_INCREMENT,
  `nip` varchar(50) NOT NULL,
  `nama_pegawai` varchar(255) NOT NULL,
  `tempat_lahir` varchar(100),
  `tanggal_lahir` date,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `golongan` varchar(10),
  `jabatan_struktural` varchar(255),
  `id_jf` int(11),
  `id_jenjang` int(11),
  `id_instansi` int(11) NOT NULL,
  `status_pegawai` enum('PNS','PPPK','Kontrak') NOT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pegawai`),
  UNIQUE KEY `nip` (`nip`),
  KEY `id_instansi` (`id_instansi`),
  KEY `id_jf` (`id_jf`),
  KEY `id_jenjang` (`id_jenjang`),
  FOREIGN KEY (`id_instansi`) REFERENCES `instansi`(`id_instansi`) ON DELETE CASCADE,
  FOREIGN KEY (`id_jf`) REFERENCES `jabatan_fungsional`(`id_jf`) ON DELETE SET NULL,
  FOREIGN KEY (`id_jenjang`) REFERENCES `jenjang_jf`(`id_jenjang`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create rekap_jf table
CREATE TABLE IF NOT EXISTS `rekap_jf` (
  `id_rekap` int(11) NOT NULL AUTO_INCREMENT,
  `id_instansi` int(11) NOT NULL,
  `id_jf` int(11) NOT NULL,
  `id_jenjang` int(11) NOT NULL,
  `jumlah_pegawai` int(11) NOT NULL DEFAULT 0,
  `dasar_hukum` text,
  `pengakuan_kementerian` enum('Ya','Tidak') DEFAULT 'Tidak',
  `catatan_tambahan` text,
  `status_validasi` enum('Belum Validasi','Sudah Validasi') DEFAULT 'Belum Validasi',
  `tanggal_validasi` datetime DEFAULT NULL,
  `tanggal_input` datetime DEFAULT NULL,
  PRIMARY KEY (`id_rekap`),
  KEY `id_instansi` (`id_instansi`),
  KEY `id_jf` (`id_jf`),
  KEY `id_jenjang` (`id_jenjang`),
  FOREIGN KEY (`id_instansi`) REFERENCES `instansi`(`id_instansi`) ON DELETE CASCADE,
  FOREIGN KEY (`id_jf`) REFERENCES `jabatan_fungsional`(`id_jf`) ON DELETE CASCADE,
  FOREIGN KEY (`id_jenjang`) REFERENCES `jenjang_jf`(`id_jenjang`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
