<?php
// Test script to verify the fix for pembina_jf column
require_once 'config/database.php';

// Test insert with pembina_jf
try {
    $test_data = [
        'kode_jf' => 'TEST001',
        'nama_jf' => 'Test Jabatan Fungsional',
        'pembina_jf' => 'Kementerian PANRB',
        'kategori' => 'keahlian',
        'pendidikan_minimal' => 'S1/D4',
        'tugas_pokok' => 'Test tugas pokok',
        'fungsi' => 'Test fungsi',
        'deskripsi' => 'Test deskripsi',
        'peraturan' => 'Test peraturan',
        'status_validasi' => 'Belum Koordinasi Penghitungan'
    ];
    
    $stmt = $conn->prepare("INSERT INTO jabatan_fungsional (kode_jf, nama_jf, pembina_jf, kategori, pendidikan_minimal, tugas_pokok, fungsi, deskripsi, peraturan, status_validasi, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
    
    if (!$stmt) {
        throw new Exception("Error preparing statement: " . $conn->error);
    }
    
    $stmt->bind_param("ssssssssss", 
        $test_data['kode_jf'],
        $test_data['nama_jf'],
        $test_data['pembina_jf'],
        $test_data['kategori'],
        $test_data['pendidikan_minimal'],
        $test_data['tugas_pokok'],
        $test_data['fungsi'],
        $test_data['deskripsi'],
        $test_data['peraturan'],
        $test_data['status_validasi']
    );
    
    if ($stmt->execute()) {
        echo "SUCCESS: Insert test passed! The pembina_jf column is working correctly.\n";
        echo "Inserted ID: " . $stmt->insert_id . "\n";
        
        // Clean up test data
        $delete_stmt = $conn->prepare("DELETE FROM jabatan_fungsional WHERE kode_jf = 'TEST001'");
        $delete_stmt->execute();
        $delete_stmt->close();
        
    } else {
        throw new Exception("Insert failed: " . $stmt->error);
    }
    
    $stmt->close();
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}

$conn->close();
?>
