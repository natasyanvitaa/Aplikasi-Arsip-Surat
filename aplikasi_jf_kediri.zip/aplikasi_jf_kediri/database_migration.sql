-- Database Migration for JF-OPD Management System
-- Execute this SQL to add new tables and modify existing ones

-- Create table for JF-OPD tracking with detailed status
CREATE TABLE IF NOT EXISTS `jf_opd_tracking` (
  `id_tracking` int(11) NOT NULL AUTO_INCREMENT,
  `id_jf` int(11) NOT NULL,
  `id_instansi` int(11) NOT NULL,
  `id_jenjang` int(11) DEFAULT NULL,
  `jumlah_pegawai` int(11) DEFAULT 0,
  `status_tracking` tinyint(1) DEFAULT 0 COMMENT '0=belum dihitung, 1=sedang dihitung, 2=diminta rekomendasi, 3=telah diminta rekomendasi, 4=diminta validasi menpan, 5=sudah divalidasi menpan, 6=dibuatkan dasar hukum',
  `tanggal_mulai` datetime DEFAULT NULL,
  `tanggal_selesai` datetime DEFAULT NULL,
  `catatan` text,
  `dasar_hukum` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tracking`),
  KEY `idx_jf_instansi` (`id_jf`, `id_instansi`),
  KEY `idx_status` (`status_tracking`),
  FOREIGN KEY (`id_jf`) REFERENCES `jabatan_fungsional`(`id_jf`) ON DELETE CASCADE,
  FOREIGN KEY (`id_instansi`) REFERENCES `instansi`(`id_instansi`) ON DELETE CASCADE,
  FOREIGN KEY (`id_jenjang`) REFERENCES `jenjang_jf`(`id_jenjang`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create table for supporting documents
CREATE TABLE IF NOT EXISTS `dokumen_pendukung` (
  `id_dokumen` int(11) NOT NULL AUTO_INCREMENT,
  `id_tracking` int(11) NOT NULL,
  `nama_file` varchar(255) NOT NULL,
  `nama_asli` varchar(255) NOT NULL,
  `ukuran_file` int(11) NOT NULL,
  `tipe_file` varchar(50) NOT NULL,
  `path_file` varchar(500) NOT NULL,
  `keterangan` text,
  `uploaded_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_dokumen`),
  KEY `idx_tracking` (`id_tracking`),
  FOREIGN KEY (`id_tracking`) REFERENCES `jf_opd_tracking`(`id_tracking`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create table for JF supervisors (Pembina JF)
CREATE TABLE IF NOT EXISTS `pembina_jf` (
  `id_pembina` int(11) NOT NULL AUTO_INCREMENT,
  `id_jf` int(11) NOT NULL,
  `nama_pembina` varchar(255) NOT NULL,
  `instansi_pembina` varchar(255) NOT NULL,
  `jabatan` varchar(255) DEFAULT NULL,
  `kontak` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status_aktif` enum('aktif','nonaktif') DEFAULT 'aktif',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pembina`),
  KEY `idx_jf` (`id_jf`),
  FOREIGN KEY (`id_jf`) REFERENCES `jabatan_fungsional`(`id_jf`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create table for JF coordinators (Koordinator JF)
CREATE TABLE IF NOT EXISTS `koordinator_jf` (
  `id_koordinator` int(11) NOT NULL AUTO_INCREMENT,
  `id_jf` int(11) NOT NULL,
  `id_instansi` int(11) NOT NULL,
  `nama_koordinator` varchar(255) NOT NULL,
  `nip` varchar(50) DEFAULT NULL,
  `jabatan` varchar(255) DEFAULT NULL,
  `kontak` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `status_aktif` enum('aktif','nonaktif') DEFAULT 'aktif',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_koordinator`),
  KEY `idx_jf_instansi` (`id_jf`, `id_instansi`),
  FOREIGN KEY (`id_jf`) REFERENCES `jabatan_fungsional`(`id_jf`) ON DELETE CASCADE,
  FOREIGN KEY (`id_instansi`) REFERENCES `instansi`(`id_instansi`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Create uploads directory structure (to be created via PHP)
-- uploads/
-- ├── dokumen_pendukung/
-- └── exports/

-- Insert sample data for testing
INSERT IGNORE INTO `pembina_jf` (`id_jf`, `nama_pembina`, `instansi_pembina`, `jabatan`, `kontak`, `email`) VALUES
(1, 'Dr. Ahmad Santoso', 'Kementerian Pendayagunaan Aparatur Negara dan Reformasi Birokrasi', 'Direktur Jabatan Fungsional', '021-12345678', 'ahmad.santoso@menpan.go.id'),
(2, 'Ir. Siti Nurhaliza, M.Si', 'Badan Kepegawaian Negara', 'Kepala Bidang JF Teknis', '021-87654321', 'siti.nurhaliza@bkn.go.id');

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS `idx_jf_opd_status` ON `jf_opd_tracking` (`status_tracking`, `created_at`);
CREATE INDEX IF NOT EXISTS `idx_dokumen_tipe` ON `dokumen_pendukung` (`tipe_file`);
