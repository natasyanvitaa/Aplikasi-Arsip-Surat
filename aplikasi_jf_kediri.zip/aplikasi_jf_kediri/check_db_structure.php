<?php
include 'db.php';

echo "Connected successfully to database: " . $dbname . "\n\n";

// Get all table names
$sql = "SHOW TABLES";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "Tables in database:\n";
    $tables = [];
    while($row = $result->fetch_array()) {
        echo "- " . $row[0] . "\n";
        $tables[] = $row[0];
    }
    
    echo "\nTable structures:\n\n";
    
    foreach ($tables as $table) {
        echo "Structure for table: $table\n";
        $sql = "DESCRIBE $table";
        $result = $conn->query($sql);
        
        if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
                echo "  - " . $row['Field'] . " (" . $row['Type'] . ")\n";
            }
        }
        echo "\n";
    }
} else {
    echo "No tables found\n";
}

$conn->close();
?>
