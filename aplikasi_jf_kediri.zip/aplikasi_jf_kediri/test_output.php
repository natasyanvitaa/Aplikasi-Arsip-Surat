<?php
file_put_contents('test_output.txt', "PHP is working correctly\n");
echo "Test completed\n";
?>
