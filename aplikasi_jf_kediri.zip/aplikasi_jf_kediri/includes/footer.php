</main>
        <footer>
            <p>&copy; <?php echo date("Y"); ?> Pemerintah Kota Kediri. All rights reserved.</p>
        </footer>
    </div>
    <script src="../assets/js/script.js"></script>
</body>
</html>
<?php
$conn->close();
?>
