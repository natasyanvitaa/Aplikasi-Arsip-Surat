<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../functions.php';

// Proteksi halaman admin
if (!is_logged_in() && !strpos($_SERVER['PHP_SELF'], 'index.php')) {
    redirect('../index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendataan JF Kota Kediri</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1>Sistem Pendataan Jabatan Fungsional Kota Kediri</h1>
            <nav>
                <ul>
                    <?php if (is_logged_in()): ?>
                        <li><a href="../admin/index.php">Dashboard</a></li>
                        <li><a href="../admin/instansi.php">Instansi</a></li>
                        <li><a href="../admin/jabatan_fungsional.php">Jabatan Fungsional</a></li>
                        <li><a href="../admin/jenjang_jf.php">Jenjang JF</a></li>
                        <li><a href="../admin/rekap_jf.php">Rekap JF Instansi</a></li>
                        <li><a href="../admin/validasi_rekap.php">Validasi Rekap</a></li>
                        <li><a href="../admin/laporan.php">Laporan</a></li>
                        <li><a href="../index.php?logout=true">Logout</a></li>
                    <?php else: ?>
                        <li><a href="../index.php">Login</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </header>
        <main>
