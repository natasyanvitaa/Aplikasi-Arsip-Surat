<?php
// Data instansi pembina jabatan fungsional dan jabatan fungsionalnya
// Berdasarkan 54 Daftar Instansi Pembina Jabatan Fungsional

$instansi_pembina = [
    'Arsip Nasional Republik Indonesia' => ['Arsiparis'],
    'Badan Informasi Geospasial' => ['Surveyor Pemetaan'],
    'Badan Intelijen Negara' => ['Agen Intelijen', 'Analis Intelijen', 'Asisten Agen Intelijen', 'Asisten Penata Kelola Intelijen', 'Penata Kelola Intelijen', 'Pengawas Intelijen', 'Pengembang Sistem Intelijen'],
    'Badan Kepegawaian Negara' => ['Analis Sumber Daya Manusia Aparatur', 'Asesor Sumber Daya Manusia Aparatur', 'Auditor Kepegawaian', 'Auditor Manajemen Aparatur Sipil Negara', 'Pranata Sumber Daya Manusia Aparatur'],
    'Badan Koordinasi Keluarga Berencana Nasional (BKKBN)' => ['Penata Kependudukan Dan Keluarga Berencana', 'Penyuluh Keluarga Berencana'],
    'Badan Meteorologi Klimatologi dan Geofisika' => ['Pengamat Metereologi dan Geofisika'],
    'Badan Narkotika Nasional' => ['Asisten Konselor Adiksi', 'Asisten Penata Laboratorium Narkotika', 'Konselor Adiksi', 'Penata Laboratorium Narkotika', 'Penyidik BNN', 'Penyuluh Narkoba'],
    'Badan Nasional Penanggulangan Bencana' => ['Analis Kebencanaan', 'Penata Penanggulangan Bencana'],
    'Badan Nasional Pencarian dan Pertolongan (Badan SAR Nasional)' => ['Rescuer'],
    'Badan Pemeriksa Keuangan' => ['Pemeriksa'],
    'Badan Pengawas Obat dan Makanan' => ['Pengawas Farmasi dan Makanan'],
    'Badan Pengawas Tenaga Nuklir' => ['Pengawas Radiasi'],
    'Badan Pengawasan Keuangan dan Pembangunan' => ['Auditor'],
    'Badan Pengkajian dan Penerapan Teknologi' => ['Perekayasa', 'Teknisi Penelitian dan Perekayasaan'],
    'Badan Pusat Statistik' => ['Pranata Komputer', 'Statistisi'],
    'Badan Siber dan Sandi Negara' => ['Manggala Informatika', 'Sandiman'],
    'Badan Standarisasi Nasional' => ['Analis Standardisasi', 'Metrolog'],
    'Badan Tenaga Nuklir Nasional' => ['Pengembang Teknologi Nuklir', 'Pranata Nuklir'],
    'Kejaksaan Agung' => ['Jaksa'],
    'Kementerian Agama' => ['Penghulu', 'Pentashih Mushaf Al-Qur\'an', 'Penyuluh Agama'],
    'Kementerian Agraria dan Tata Ruang/Badan Pertanahan Nasional' => ['Asisten Penata Kadastral', 'Penata Kadastral', 'Penata Pertanahan', 'Penata Ruang'],
    'Kementerian Badan Usaha Milik Negara' => ['Penata Kelola Perusahaan Negara'],
    'Kementerian Dalam Negeri' => ['Administrator Database Kependudukan', 'Analis Kebakaran', 'Operator Sistem Informasi Administrasi Kependudukan (Operator SIAK)', 'Pemadam Kebakaran', 'Pengawas Penyelenggaraan Urusan Pemerintahan Daerah', 'Polisi Pamong Praja'],
    'Kementerian Desa, Pembangunan Daerah Tertinggal, dan Transmigrasi' => ['Penggerak Swadaya Masyarakat'],
    'Kementerian Energi dan Sumber Daya Mineral' => ['Inspektur Ketenagalistrikan', 'Inspektur Minyak dan Gas Bumi', 'Inspektur Tambang', 'Pengamat Gunung Api', 'Penyelidik Bumi'],
    'Kementerian Hukum dan Hak Asasi Manusia' => ['Analis Hukum', 'Analis Keimigrasian', 'Asisten Pembimbing Kemasyarakatan', 'Kurator Keperdataan', 'Pembimbing Kemasyarakatan', 'Pemeriksa Desain Industri', 'Pemeriksa Keimigrasian', 'Pemeriksa Merek', 'Pemeriksa Paten', 'Penyuluh Hukum', 'Perancang Peraturan Perundang-undangan'],
    'Kementerian Kelautan dan Perikanan' => ['Analis Akuakultur', 'Analis Pasar Hasil Perikanan', 'Asisten Inspektur Mutu Hasil Perikanan', 'Asisten Pembina Mutu Hasil Kelautan dan Perikanan', 'Asisten Pengelola Produksi Perikanan Tangkap', 'Inspektur Mutu Hasil Perikanan', 'Pembina Mutu Hasil Kelautan dan Perikanan', 'Pengawas Perikanan', 'Pengelola Produksi Perikanan Tangkap', 'Teknisi Akuakultur', 'Teknisi Kesehatan Ikan'],
    'Kementerian Kesehatan' => ['Administrator Kesehatan', 'Apoteker', 'Asisten Apoteker', 'Asisten Penata Anestesi', 'Bidan', 'Dokter', 'Dokter Gigi', 'Dokter Pendidik Klinis', 'Entomolog Kesehatan', 'Epidemiolog Kesehatan', 'Fisikawan Medis', 'Fisioterapis', 'Nutrisionis', 'Okupasi Terapis', 'Orthotis Prostetis', 'Pembimbing Kesehatan Kerja', 'Penata Anestesi', 'Penyuluh Kesehatan Masyarakat', 'Perawat', 'Perekam Medis', 'Pranata Laboratorium Kesehatan', 'Psikolog Klinis', 'Radiografer', 'Refraksionis Optisien', 'Sanitarian', 'Teknisi Elektromedis', 'Teknisi Gigi', 'Teknisi Transfusi Darah', 'Terapis Gigi Dan Mulut', 'Terapis Wicara'],
    'Kementerian Ketenagakerjaan' => ['Instruktur', 'Mediator Hubungan Industrial', 'Pengantar Kerja', 'Pengawas Ketenagakerjaan', 'Penguji Keselamatan dan Kesehatan Kerja'],
    'Kementerian Keuangan' => ['Analis Anggaran', 'Analis Keuangan Pusat dan Daerah', 'Analis Pembiayaan dan Risiko Keuangan', 'Analis Pengelolaan Keuangan APBN', 'Analis Perbendaharaan Negara', 'Asisten Penilai Pajak', 'Asisten Penyuluh Pajak', 'Pelelang', 'Pembina Teknis Perbendaharaan Negara', 'Pemeriksa Bea dan Cukai', 'Pemeriksa Pajak', 'Penata Laksana Barang', 'Penilai Pajak', 'Penilai Pemerintah', 'Penyuluh Pajak', 'Pranata Keuangan APBN'],
    'Kementerian Komunikasi dan Informatika' => ['Asisten Penguji Perangkat Telekomunikasi', 'Asisten Pranata Siaran', 'Asisten Teknisi Siaran', 'Pengendali Frekuensi Radio', 'Penguji Perangkat Telekomunikasi', 'Pranata Hubungan Masyarakat', 'Pranata Siaran', 'Teknisi Siaran'],
    'Kementerian Koperasi dan Usaha Kecil dan Menengah' => ['Pengawas Koperasi'],
    'Kementerian Lingkungan Hidup dan Kehutanan' => ['Pengawas Lingkungan Hidup', 'Pengelola Ekosistem Laut dan Pesisir', 'Pengelola Kesehatan Ikan', 'Pengendali Dampak Lingkungan', 'Pengendali Ekosistem Hutan', 'Pengendali Hama dan Penyakit Ikan', 'Penyuluh Kehutanan', 'Penyuluh Lingkungan Hidup', 'Penyuluh Perikanan', 'Polisi Kehutanan'],
    'Kementerian Luar Negeri' => ['Diplomat', 'Penata Kanselerai', 'Pranata Informasi Diplomatik'],
    'Kementerian Pekerjaan Umum dan Perumahan' => ['Pembina Jasa Konstruksi', 'Teknik Jalan dan Jembatan', 'Teknik Pengairan', 'Teknik Penyehatan Lingkungan', 'Teknik Tata Bangunan dan Perumahan'],
    'Kementerian Pemuda dan Olahraga' => ['Asisten Pelatih Olahraga', 'Pelatih Olahraga'],
    'Kementerian Pendidikan dan Kebudayaan' => ['Dosen', 'Guru', 'Pamong Belajar', 'Pamong Budaya', 'Pengawas Sekolah', 'Pengembang Kurikulum', 'Pengembang Penilaian Pendidikan', 'Pengembang Teknologi Pembelajaran', 'Penilik', 'Pranata Laboratorium Pendidikan', 'Widyaprada'],
    'Kementerian Perdagangan' => ['Analis Investigasi dan Pengamanan Perdagangan', 'Analis Perdagangan', 'Negosiator Perdagangan', 'Pemeriksa Perdagangan Berjangka Komoditi', 'Penera', 'Pengamat Tera', 'Pengawas Kemetrologian', 'Pengawas Perdagangan', 'Penguji Mutu Barang', 'Penjamin Mutu Produk', 'Pranata Laboratorium Kemetrologian'],
    'Kementerian Perencanaan Pembangunan Nasional/Badan Perencanaan Pembangunan Nasional' => ['Perencana'],
    'Kementerian Perhubungan' => ['Asisten Inspektur Angkutan Udara', 'Asisten Inspektur Bandar Udara', 'Asisten Inspektur Keamanan Penerbangan', 'Asisten Inspektur Kelaikudaraan Pesawat Udara', 'Asisten Inspektur Navigasi Penerbangan', 'Asisten Inspektur Pengoperasian Pesawat Udara', 'Inspektur Angkutan Udara', 'Inspektur Bandar Udara', 'Inspektur Keamanan Penerbangan', 'Inspektur Kelaikudaraan Pesawat Udara', 'Inspektur Navigasi Penerbangan', 'Inspektur Pengoperasian Pesawat Udara', 'Pengawas Keselamatan Pelayaran', 'Penguji Kendaraan Bermotor', 'Teknisi Penerbangan'],
    'Kementerian Perindustrian' => ['Asesor Manajemen Mutu Industri', 'Penyuluh Perindustrian dan Perdagangan'],
    'Kementerian Pertahanan' => ['Analis Pertahanan Negara', 'Kataloger'],
    'Kementerian Pertanian' => ['Analis Ketahanan Pangan', 'Analis Pasar Hasil Pertanian', 'Analis Perkarantinaan Tumbuhan', 'Dokter Hewan Karantina', 'Medik Veteriner', 'Paramedik Karantina Hewan', 'Paramedik Veteriner', 'Pemeriksa Karantina Tumbuhan', 'Pemeriksa Perlindungan Varietas Tanaman', 'Pengawas Alat dan Mesin Pertanian', 'Pengawas Benih Tanaman', 'Pengawas Bibit Ternak', 'Pengawas Mutu Hasil Pertanian', 'Pengawas Mutu Pakan', 'Pengendali Organisme Pengganggu Tumbuhan', 'Penyuluh Pertanian'],
    'Kementerian Sekretariat Kabinet' => ['Penerjemah'],
    'Kementerian Sosial' => ['Pekerja Sosial', 'Penyuluh Sosial'],
    'Lembaga Administrasi Negara (LAN)' => ['Analis Kebijakan', 'Widyaiswara'],
    'Lembaga Ilmu Pengetahuan Indonesia' => ['Analis Data Ilmiah', 'Analis Pemanfaatan Ilmu Pengetahuan Dan Teknologi', 'Analis Perkebunrayaan', 'Kurator Koleksi Hayati', 'Penata Penerbitan Ilmiah', 'Peneliti', 'Teknisi Perkebunrayaan'],
    'Lembaga Kebijakan Pengadaan Barang/Jasa Pemerintah' => ['Pengelola Pengadaan Barang/Jasa'],
    'Perpustakaan Nasional' => ['Pustakawan'],
    'PPATK' => ['Analis Transaksi Keuangan'],
    'Sekjen DPR RI' => ['Analis Anggaran Pendapatan dan Belanja Negara', 'Analis Pemantauan Peraturan Perundang-Undangan Legislatif', 'Asisten Perisalah Legislatif', 'Perisalah Legislatif'],
    'Sekjen Komisi Pemilihan Umum' => ['Penata Kelola Pemilihan Umum'],
    'Sekretariat Jenderal Komisi Yudisial' => ['Penata Kehakiman'],
    'Sekretariat Mahkamah Agung' => ['Pranata Peradilan']
];

// Array untuk dropdown pembina jabatan fungsional
$pembina_options = array_keys($instansi_pembina);

// Fungsi untuk mendapatkan jabatan fungsional berdasarkan pembina
function getJabatanByPembina($pembina) {
    global $instansi_pembina;
    return isset($instansi_pembina[$pembina]) ? $instansi_pembina[$pembina] : [];
}
?>
