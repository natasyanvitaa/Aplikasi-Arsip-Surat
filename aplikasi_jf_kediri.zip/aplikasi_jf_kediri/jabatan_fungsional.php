<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php'; // Pastikan file ini berisi koneksi database
require_once 'functions.php'; // Include functions.php

// Proteksi halaman: hanya admin yang bisa mengakses
require_login();
require_admin();

// Definisi status validasi
$status_validasi_options = [
    'Belum Koordinasi Penghitungan' => 'Belum Koordinasi Penghitungan',
    'Koordinasi Penghitungan dengan Bappeda' => 'Koordinasi Penghitungan dengan Bappeda',
    'Bimbingan Penghitungan dari Kemendes' => 'Bimbingan Penghitungan dari Kemendes',
    'Proses Pengajuan Validasi Menpan' => 'Proses Pengajuan Validasi Menpan',
    'Sudah mendapat validasi Menpan' => 'Sudah mendapat validasi Menpan',
    'mendapatkan rekomendasi dari instansi pembina' => 'Mendapatkan rekomendasi dari instansi pembina'
];

$kategori_jf = [
    'keahlian' => 'JF Keahlian',
    'keterampilan' => 'JF Keterampilan'
];

$pendidikan_options = [
    'SMA/SMK' => 'SMA/SMK',
    'D3' => 'Diploma 3 (D3)',
    'S1/D4' => 'Sarjana/Diploma 4 (S1/D4)',
    'S2' => 'Magister (S2)',
    'S3' => 'Doktor (S3)'
];

// CRUD Operations
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        if (isset($_POST['action'])) {
            $action = $_POST['action'];
            
            if ($action == 'add') {
                $kode_jf = sanitize_input($_POST['kode_jf']);
                $nama_jf = sanitize_input($_POST['nama_jf']);
                $kategori = sanitize_input($_POST['kategori']);
                $pendidikan_minimal = sanitize_input($_POST['pendidikan_minimal']);
                $angka_kredit_minimal = floatval($_POST['angka_kredit_minimal']);
                $tugas_pokok = sanitize_input($_POST['tugas_pokok']);
                $fungsi = sanitize_input($_POST['fungsi']);
                $deskripsi = sanitize_input($_POST['deskripsi']);
                $status_validasi = sanitize_input($_POST['status_validasi']);
                
                if (empty($kode_jf) || empty($nama_jf)) {
                    throw new Exception("Kode JF dan Nama JF harus diisi!");
                }
                
                // Cek duplikasi kode
                $check_stmt = $conn->prepare("SELECT id_jf FROM jabatan_fungsional WHERE kode_jf = ?");
                $check_stmt->bind_param("s", $kode_jf);
                $check_stmt->execute();
                if ($check_stmt->get_result()->num_rows > 0) {
                    throw new Exception("Kode JF sudah ada!");
                }
                $check_stmt->close();
                
                $stmt = $conn->prepare("INSERT INTO jabatan_fungsional (kode_jf, nama_jf, kategori, pendidikan_minimal, angka_kredit_minimal, tugas_pokok, fungsi, deskripsi, status_validasi, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())");
                $stmt->bind_param("ssssdssss", $kode_jf, $nama_jf, $kategori, $pendidikan_minimal, $angka_kredit_minimal, $tugas_pokok, $fungsi, $deskripsi, $status_validasi);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data JF berhasil ditambahkan!";
                } else {
                    throw new Exception("Gagal menambahkan data: " . $stmt->error);
                }
                $stmt->close();
                
            } elseif ($action == 'edit') {
                $id = intval($_POST['id']);
                $kode_jf = sanitize_input($_POST['kode_jf']);
                $nama_jf = sanitize_input($_POST['nama_jf']);
                $kategori = sanitize_input($_POST['kategori']);
                $pendidikan_minimal = sanitize_input($_POST['pendidikan_minimal']);
                $organisasi_profesi = sanitize_input($_POST['organisasi_profesi']);
                $angka_kredit_minimal = floatval($_POST['angka_kredit_minimal']);
                $tugas_pokok = sanitize_input($_POST['tugas_pokok']);
                $fungsi = sanitize_input($_POST['fungsi']);
                $deskripsi = sanitize_input($_POST['deskripsi']);
                $status_aktif = sanitize_input($_POST['status_aktif']);
                $status_validasi = sanitize_input($_POST['status_validasi']);
                
                if (empty($kode_jf) || empty($nama_jf)) {
                    throw new Exception("Kode JF dan Nama JF harus diisi!");
                }
                
                // Cek duplikasi kode (exclude current record)
                $check_stmt = $conn->prepare("SELECT id_jf FROM jabatan_fungsional WHERE kode_jf = ? AND id_jf != ?");
                $check_stmt->bind_param("si", $kode_jf, $id);
                $check_stmt->execute();
                if ($check_stmt->get_result()->num_rows > 0) {
                    throw new Exception("Kode JF sudah ada!");
                }
                $check_stmt->close();
                
                $stmt = $conn->prepare("UPDATE jabatan_fungsional SET kode_jf = ?, nama_jf = ?, kategori = ?, pendidikan_minimal = ?, organisasi_profesi = ?, angka_kredit_minimal = ?, tugas_pokok = ?, fungsi = ?, deskripsi = ?, status_aktif = ?, status_validasi = ?, updated_at = NOW() WHERE id_jf = ?");
                $stmt->bind_param("sssssdsssssi", $kode_jf, $nama_jf, $kategori, $pendidikan_minimal, $organisasi_profesi, $angka_kredit_minimal, $tugas_pokok, $fungsi, $deskripsi, $status_aktif, $status_validasi, $id);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data JF berhasil diperbarui!";
                } else {
                    throw new Exception("Gagal memperbarui data: " . $stmt->error);
                }
                $stmt->close();
                
            } elseif ($action == 'delete') {
                $id = intval($_POST['id']);
                
                // Cek apakah JF masih digunakan
                $check_stmt = $conn->prepare("SELECT COUNT(*) as count FROM rekap_jf WHERE id_jf = ?");
                $check_stmt->bind_param("i", $id);
                $check_stmt->execute();
                $result = $check_stmt->get_result();
                $count = $result->fetch_assoc()['count'];
                $check_stmt->close();
                
                if ($count > 0) {
                    throw new Exception("JF tidak dapat dihapus karena masih digunakan dalam rekap!");
                }
                
                $stmt = $conn->prepare("DELETE FROM jabatan_fungsional WHERE id_jf = ?");
                $stmt->bind_param("i", $id);
                
                if ($stmt->execute()) {
                    $_SESSION['success_message'] = "Data JF berhasil dihapus!";
                } else {
                    throw new Exception("Gagal menghapus data: " . $stmt->error);
                }
                $stmt->close();
            }
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
    }
    
    header("Location: jabatan_fungsional.php");
    exit();
}

// Get data for edit
$data_to_edit = null;
if (isset($_GET['action']) && $_GET['action'] == 'edit' && isset($_GET['id'])) {
    $edit_id = intval($_GET['id']);
    $stmt = $conn->prepare("SELECT * FROM jabatan_fungsional WHERE id_jf = ?");
    $stmt->bind_param("i", $edit_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $data_to_edit = $result->fetch_assoc();
    $stmt->close();
}

// Get main data with filters
$filter_kategori = isset($_GET['filter_kategori']) ? $_GET['filter_kategori'] : '';
$filter_status = isset($_GET['filter_status']) ? $_GET['filter_status'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$where_conditions = [];
$params = [];
$types = "";

if ($filter_kategori) {
    $where_conditions[] = "kategori = ?";
    $params[] = $filter_kategori;
    $types .= "s";
}

if ($filter_status) {
    $where_conditions[] = "status_validasi = ?";
    $params[] = $filter_status;
    $types .= "s";
}

if ($search) {
    $where_conditions[] = "(nama_jf LIKE ? OR kode_jf LIKE ? OR organisasi_profesi LIKE ?)";
    $search_param = "%" . $search . "%";
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
    $types .= "sss";
}

$where_clause = "";
if (!empty($where_conditions)) {
    $where_clause = "WHERE " . implode(" AND ", $where_conditions);
}

$sql = "SELECT * FROM jabatan_fungsional $where_clause ORDER BY kategori, nama_jf";

if (!empty($params)) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($sql);
}

// Get statistics
$stats = [];
$stats_query = "SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN kategori = 'keahlian' THEN 1 ELSE 0 END) as keahlian,
    SUM(CASE WHEN kategori = 'keterampilan' THEN 1 ELSE 0 END) as keterampilan,
    SUM(CASE WHEN status_aktif = 'aktif' THEN 1 ELSE 0 END) as aktif,
    SUM(CASE WHEN status_validasi = 'Sudah mendapat validasi Menpan' THEN 1 ELSE 0 END) as tervalidasi
    FROM jabatan_fungsional";
$stats_result = $conn->query($stats_query);
$stats = $stats_result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Jabatan Fungsional - Sistem JF Kota Kediri</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* CSS yang sudah ada */
        :root {
            --primary-gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --success-gradient: linear-gradient(135deg, #81FBB8 0%, #28C76F 100%);
            --warning-gradient: linear-gradient(135deg, #FFD93D 0%, #FF6B6B 100%);
            --info-gradient: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
        }

        body {
            background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
            min-height: 100vh;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding-top: 70px;
        }

        .navbar {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            background: var(--primary-gradient) !important;
        }
        .navbar-brand, .nav-link {
            color: white !important;
        }
        .navbar-brand:hover, .nav-link:hover {
            color: rgba(255, 255, 255, 0.8) !important;
        }

        .card {
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            border: none;
            border-radius: 15px;
            transition: transform 0.3s ease;
        }

        .card:hover {
            transform: translateY(-2px);
        }

        .card-header {
            background: var(--primary-gradient);
            color: white;
            border-radius: 15px 15px 0 0 !important;
            border: none;
            padding: 20px;
        }

        .btn {
            border-radius: 8px;
            padding: 10px 20px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary {
            background: var(--primary-gradient);
            border: none;
        }

        .btn-success {
            background: var(--success-gradient);
            border: none;
        }

        .btn-info {
            background: var(--info-gradient);
            border: none;
        }

        .btn-danger {
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5253 100%);
            border: none;
        }

        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        }

        .table {
            border-radius: 10px;
            overflow: hidden;
        }

        .table th {
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
            font-weight: 700;
            border: none;
            color: #495057;
            padding: 15px 12px;
        }

        .table td {
            padding: 15px 12px;
            vertical-align: middle;
            border-color: #f1f3f4;
        }

        .form-control {
            border-radius: 8px;
            border: 2px solid #e0e6ed;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }

        .badge-keahlian {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 8px 15px;
            border-radius: 25px;
            font-size: 11px;
            font-weight: 600;
        }

        .badge-keterampilan {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            color: white;
            padding: 8px 15px;
            border-radius: 25px;
            font-size: 11px;
            font-weight: 600;
        }

        .alert {
            border-radius: 8px;
            margin-top: 20px;
        }

        .stats-card {
            background: white;
            border-radius: 15px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .stats-card h4 {
            color: #667eea;
            font-weight: 700;
        }
        .stats-card p {
            font-size: 2.5em;
            font-weight: 800;
            color: #333;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#">Sistem JF Kota Kediri</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="admin/dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
                    </li>
                    <li class="nav-item active">
                        <a class="nav-link" href="jabatan_fungsional.php"><i class="fas fa-briefcase"></i> Jabatan Fungsional <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="rekap_jf.php"><i class="fas fa-users"></i> Rekap JF</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-user-circle"></i> <?php echo $_SESSION['username']; ?>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="index.php?logout=true"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <h2 class="mb-4 text-center" style="color: #495057;">Manajemen Jabatan Fungsional</h2>

        <?php 
        if (isset($_SESSION['success_message'])) {
            echo show_alert($_SESSION['success_message'], 'success');
            unset($_SESSION['success_message']);
        }
        if (isset($_SESSION['error_message'])) {
            echo show_alert($_SESSION['error_message'], 'danger');
            unset($_SESSION['error_message']);
        }
        ?>

        <div class="row mb-4">
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>Total JF</h4>
                    <p><?php echo $stats['total']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>JF Keahlian</h4>
                    <p><?php echo $stats['keahlian']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>JF Keterampilan</h4>
                    <p><?php echo $stats['keterampilan']; ?></p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stats-card">
                    <h4>JF Tervalidasi</h4>
                    <p><?php echo $stats['tervalidasi']; ?></p>
                </div>
            </div>
        </div>

        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><?php echo $data_to_edit ? 'Edit Data Jabatan Fungsional' : 'Tambah Jabatan Fungsional Baru'; ?></span>
                <?php if ($data_to_edit): ?>
                    <a href="jabatan_fungsional.php" class="btn btn-sm btn-info">Batal Edit</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <form action="jabatan_fungsional.php" method="POST">
                    <input type="hidden" name="action" value="<?php echo $data_to_edit ? 'edit' : 'add'; ?>">
                    <?php if ($data_to_edit): ?>
                        <input type="hidden" name="id" value="<?php echo $data_to_edit['id_jf']; ?>">
                    <?php endif; ?>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="kode_jf">Kode JF <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="kode_jf" name="kode_jf" value="<?php echo $data_to_edit ? htmlspecialchars($data_to_edit['kode_jf']) : ''; ?>" required>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="nama_jf">Nama JF <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="nama_jf" name="nama_jf" value="<?php echo $data_to_edit ? htmlspecialchars($data_to_edit['nama_jf']) : ''; ?>" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="kategori">Kategori</label>
                            <select class="form-control" id="kategori" name="kategori" required>
                                <?php foreach ($kategori_jf as $value => $label): ?>
                                    <option value="<?php echo $value; ?>" <?php echo ($data_to_edit && $data_to_edit['kategori'] == $value) ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group col-md-6">
                            <label for="pendidikan_minimal">Pendidikan Minimal</label>
                            <select class="form-control" id="pendidikan_minimal" name="pendidikan_minimal" required>
                                <?php foreach ($pendidikan_options as $value => $label): ?>
                                    <option value="<?php echo $value; ?>" <?php echo ($data_to_edit && $data_to_edit['pendidikan_minimal'] == $value) ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="form-row">
                                        <div class="form-group col-md-6">
                                            <label for="tugas_pokok">Tugas Pokok</label>
                                            <textarea class="form-control" id="tugas_pokok" name="tugas_pokok" rows="3"><?php echo $data_to_edit ? htmlspecialchars($data_to_edit['tugas_pokok']) : ''; ?></textarea>
                                        </div>
                        <div class="form-group col-md-6">
                            <label for="tugas_pokok">Tugas Pokok</label>
                            <textarea class="form-control" id="tugas_pokok" name="tugas_pokok" rows="3"><?php echo $data_to_edit ? htmlspecialchars($data_to_edit['tugas_pokok']) : ''; ?></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="tugas_pokok">Tugas Pokok</label>
                        <textarea class="form-control" id="tugas_pokok" name="tugas_pokok" rows="3"><?php echo $data_to_edit ? htmlspecialchars($data_to_edit['tugas_pokok']) : ''; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="fungsi">Fungsi</label>
                        <textarea class="form-control" id="fungsi" name="fungsi" rows="3"><?php echo $data_to_edit ? htmlspecialchars($data_to_edit['fungsi']) : ''; ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="deskripsi">Deskripsi</label>
                        <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3"><?php echo $data_to_edit ? htmlspecialchars($data_to_edit['deskripsi']) : ''; ?></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <label for="status_validasi">Status Validasi</label>
                            <select class="form-control" id="status_validasi" name="status_validasi" required>
                                <?php foreach ($status_validasi_options as $value => $label): ?>
                                    <option value="<?php echo $value; ?>" <?php echo ($data_to_edit && $data_to_edit['status_validasi'] == $value) ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php if ($data_to_edit): ?>
                        <div class="form-group col-md-6">
                            <label for="status_aktif">Status Aktif</label>
                            <select class="form-control" id="status_aktif" name="status_aktif" required>
                                <option value="aktif" <?php echo ($data_to_edit['status_aktif'] == 'aktif') ? 'selected' : ''; ?>>Aktif</option>
                                <option value="nonaktif" <?php echo ($data_to_edit['status_aktif'] == 'nonaktif') ? 'selected' : ''; ?>>Nonaktif</option>
                            </select>
                        </div>
                        <?php endif; ?>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        <i class="fas fa-save"></i> <?php echo $data_to_edit ? 'Update Data' : 'Tambah Data'; ?>
                    </button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                Daftar Jabatan Fungsional
            </div>
            <div class="card-body">
                <form action="jabatan_fungsional.php" method="GET" class="form-inline mb-3">
                    <div class="form-group mr-2">
                        <label for="filter_kategori" class="sr-only">Filter Kategori</label>
                        <select class="form-control" id="filter_kategori" name="filter_kategori">
                            <option value="">Semua Kategori</option>
                            <?php foreach ($kategori_jf as $value => $label): ?>
                                <option value="<?php echo $value; ?>" <?php echo ($filter_kategori == $value) ? 'selected' : ''; ?>>
                                    <?php echo $label; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group mr-2">
                        <label for="filter_status" class="sr-only">Filter Status Validasi</label>
                        <select class="form-control" id="filter_status" name="filter_status">
                            <option value="">Semua Status Validasi</option>
                            <?php foreach ($status_validasi_options as $value => $label): ?>
                                <option value="<?php echo $value; ?>" <?php echo ($filter_status == $value) ? 'selected' : ''; ?>>
                                    <?php echo $label; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group mr-2">
                        <label for="search" class="sr-only">Cari</label>
                        <input type="text" class="form-control" id="search" name="search" placeholder="Cari JF..." value="<?php echo htmlspecialchars($search); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
                    <a href="jabatan_fungsional.php" class="btn btn-secondary ml-2"><i class="fas fa-sync-alt"></i> Reset</a>
                </form>

                <div class="table-responsive">
                    <table class="table table-hover table-striped">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Kode JF</th>
                                <th>Nama JF</th>
                                <th>Kategori</th>
                                <th>Pendidikan Min.</th>
                                <th>Angka Kredit Min.</th>
                                <th>Status Validasi</th>
                                <th>Status Aktif</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($result->num_rows > 0): ?>
                                <?php $no = 1; while ($row = $result->fetch_assoc()): ?>
                                    <tr>
                                        <td><?php echo $no++; ?></td>
                                        <td><?php echo htmlspecialchars($row['kode_jf']); ?></td>
                                        <td><?php echo htmlspecialchars($row['nama_jf']); ?></td>
                                        <td>
                                            <span class="badge <?php echo ($row['kategori'] == 'keahlian') ? 'badge-keahlian' : 'badge-keterampilan'; ?>">
                                                <?php echo $kategori_jf[$row['kategori']]; ?>
                                            </span>
                                        </td>
                                        <td><?php echo htmlspecialchars($row['pendidikan_minimal']); ?></td>
                                        <td><?php echo htmlspecialchars($row['angka_kredit_minimal']); ?></td>
                                        <td><?php echo htmlspecialchars($row['status_validasi']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo ($row['status_aktif'] == 'aktif') ? 'success' : 'danger'; ?>">
                                                <?php echo ucfirst($row['status_aktif']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="jabatan_fungsional.php?action=edit&id=<?php echo $row['id_jf']; ?>" class="btn btn-sm btn-warning mb-1" title="Edit"><i class="fas fa-edit"></i></a>
                                            <button type="button" class="btn btn-sm btn-danger mb-1" data-toggle="modal" data-target="#deleteModal" data-id="<?php echo $row['id_jf']; ?>" title="Hapus"><i class="fas fa-trash"></i></button>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="9" class="text-center">Tidak ada data jabatan fungsional.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    Apakah Anda yakin ingin menghapus data ini?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <form id="deleteForm" method="POST" action="jabatan_fungsional.php">
                        <input type="hidden" name="action" value="delete">
                        <input type="hidden" name="id" id="delete_id">
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $('#deleteModal').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget); // Button that triggered the modal
            var id = button.data('id'); // Extract info from data-* attributes
            var modal = $(this);
            modal.find('#delete_id').val(id);
        });
    </script>
</body>
</html>
