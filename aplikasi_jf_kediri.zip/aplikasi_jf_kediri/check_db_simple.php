<?php
// Simple database connection and table check
require_once 'db.php';

echo "Database Connection Test\n";
echo "========================\n";

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

echo "Connected successfully to database: " . $conn->real_escape_string($dbname) . "\n\n";

// Get all tables
echo "Database Tables:\n";
echo "================\n";
$sql = "SHOW TABLES";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_row()) {
        echo "- " . $row[0] . "\n";
    }
} else {
    echo "No tables found\n";
}

echo "\n";

// Check if specific tables exist
$tables_to_check = ['instansi', 'jenjang_jf', 'jabatan_fungsional', 'pegawai', 'rekap_jf'];

echo "Checking specific tables:\n";
echo "==========================\n";
foreach ($tables_to_check as $table) {
    $sql = "SHOW TABLES LIKE '$table'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo "✓ Table '$table' exists\n";
    } else {
        echo "✗ Table '$table' does not exist\n";
    }
}

$conn->close();
echo "\nTest completed\n";
?>
