-- SQL script to add peraturan column to jabatan_fungsional table
-- Run this script to add the missing peraturan column

ALTER TABLE jabatan_fungsional 
ADD COLUMN IF NOT EXISTS peraturan TEXT 
AFTER deskripsi;

-- Verify the column was added
DESCRIBE jabatan_fungsional;
